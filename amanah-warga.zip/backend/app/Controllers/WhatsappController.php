<?php
namespace App\Controllers;

class WhatsappController extends BaseController {
    public function index() {
        return $this->response->setJSON(['status' => 'success', 'data' => []]);
    }

    public function store() {
        return $this->response->setJSON(['status' => 'success', 'message' => 'Data Whatsapp berhasil ditambahkan']);
    }

    public function show($id) {
        return $this->response->setJSON(['status' => 'success', 'data' => null]);
    }

    public function update($id) {
        return $this->response->setJSON(['status' => 'success', 'message' => 'Data Whatsapp berhasil diperbarui']);
    }

    public function destroy($id) {
        return $this->response->setJSON(['status' => 'success', 'message' => 'Data Whatsapp berhasil dihapus']);
    }
}
