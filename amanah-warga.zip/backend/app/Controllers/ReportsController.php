<?php
namespace App\Controllers;

class ReportsController extends BaseController {
    public function index() {
        return $this->response->setJSON(['status' => 'success', 'data' => []]);
    }

    public function store() {
        return $this->response->setJSON(['status' => 'success', 'message' => 'Data Reports berhasil ditambahkan']);
    }

    public function show($id) {
        return $this->response->setJSON(['status' => 'success', 'data' => null]);
    }

    public function update($id) {
        return $this->response->setJSON(['status' => 'success', 'message' => 'Data Reports berhasil diperbarui']);
    }

    public function destroy($id) {
        return $this->response->setJSON(['status' => 'success', 'message' => 'Data Reports berhasil dihapus']);
    }
}
