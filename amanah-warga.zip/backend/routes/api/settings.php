<?php
use App\Controllers\SettingsController;

$router->get('/api/settings', [SettingsController::class, 'index']);
$router->post('/api/settings', [SettingsController::class, 'store']);
$router->get('/api/settings/{id}', [SettingsController::class, 'show']);
$router->put('/api/settings/{id}', [SettingsController::class, 'update']);
$router->delete('/api/settings/{id}', [SettingsController::class, 'destroy']);
