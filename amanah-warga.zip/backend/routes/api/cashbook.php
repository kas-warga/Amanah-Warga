<?php
use App\Controllers\CashbookController;

$router->get('/api/cashbook', [CashbookController::class, 'index']);
$router->post('/api/cashbook', [CashbookController::class, 'store']);
$router->get('/api/cashbook/{id}', [CashbookController::class, 'show']);
$router->put('/api/cashbook/{id}', [CashbookController::class, 'update']);
$router->delete('/api/cashbook/{id}', [CashbookController::class, 'destroy']);
