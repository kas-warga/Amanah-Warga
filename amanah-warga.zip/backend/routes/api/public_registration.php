<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

ini_set('display_errors', '0');
error_reporting(E_ALL);

try {
    $configPath = __DIR__ . '/../../config/database.php';
    if (!file_exists($configPath)) throw new Exception("File database.php tidak ditemukan");
    
    require_once $configPath;
    $db = getDbConnection();
    if (!$db) throw new Exception("Koneksi database gagal");
    
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // PERBAIKAN: Memisahkan blok try-catch agar jika ktp_image sudah ada, tenant_id tetap dibuat
    try {
        $db->exec("ALTER TABLE houses ADD COLUMN ktp_image VARCHAR(255) NULL AFTER phone");
    } catch (Exception $e) {}
    
    try {
        $db->exec("ALTER TABLE houses ADD COLUMN tenant_id INT NULL AFTER ktp_image");
    } catch (Exception $e) {}

    $kodeLisensi = trim($_POST['kode_lisensi'] ?? '');
    $block = trim($_POST['block'] ?? '');
    $houseNumber = trim($_POST['house_number'] ?? '');
    $ownerName = trim($_POST['owner_name'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $phone = trim($_POST['phone_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $occupancyStatus = $_POST['occupancy_status'] ?? 'occupied';
    $totalResidents = (int)($_POST['total_residents'] ?? 1);

    if (empty($kodeLisensi)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Link tidak valid (Tidak ada Token).']);
        exit();
    }

    if (empty($block) || empty($houseNumber) || empty($ownerName) || empty($password) || empty($phone)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Semua kolom berlabel wajib harus diisi.']);
        exit();
    }

    // --- ALGORITMA VALIDASI TOKEN 1 JAM ---
    $decodedToken = base64_decode($kodeLisensi);
    $tokenParts = explode('|', $decodedToken);
    
    if (count($tokenParts) !== 3) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Format link pendaftaran rusak atau tidak valid.']);
        exit();
    }
    
    list($adminId, $expiresAt, $signature) = $tokenParts;
    $secretKey = "AmanahWarga_Secret_2026";
    $expectedSignature = hash_hmac('sha256', $adminId . '|' . $expiresAt, $secretKey);
    
    // 1. Cek Keaslian Link (Apakah dimanipulasi?)
    if (!hash_equals($expectedSignature, $signature)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Link pendaftaran ilegal atau palsu.']);
        exit();
    }
    
    // 2. Cek Kadaluarsa (Apakah sudah lewat 1 Jam?)
    if (time() > (int)$expiresAt) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Link Pendaftaran KADALUARSA (Batas 1 Jam terlewati). Silakan minta link baru ke Pengurus RT.']);
        exit();
    }
    
    $tenantId = (int)$adminId;
    // --- AKHIR VALIDASI TOKEN ---

    $stmtCheckUser = $db->prepare("SELECT id FROM users WHERE username = ?");
    $stmtCheckUser->execute([$phone]);
    if ($stmtCheckUser->fetch()) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Nomor WhatsApp ini sudah terdaftar sebagai Akun Warga.']);
        exit();
    }

    if (!isset($_FILES['ktp_image']) || $_FILES['ktp_image']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Gagal mengunggah foto KTP.']);
        exit();
    }

    $uploadDir = __DIR__ . '/../../uploads/ktp/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $fileExtension = strtolower(pathinfo($_FILES['ktp_image']['name'], PATHINFO_EXTENSION));
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf'];
    if (!in_array($fileExtension, $allowedExtensions)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Format file KTP harus JPG, JPEG, PNG, atau PDF.']);
        exit();
    }

    $newFileName = 'ktp_' . preg_replace('/[^0-9]/', '', $phone) . '_' . time() . '.' . $fileExtension;
    $targetFilePath = $uploadDir . $newFileName;

    if (!move_uploaded_file($_FILES['ktp_image']['tmp_name'], $targetFilePath)) {
        throw new Exception("Gagal menyimpan file KTP.");
    }
    $ktpDbPath = 'uploads/ktp/' . $newFileName;

    $db->beginTransaction();

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $emailToSave = !empty($email) ? $email : $phone . '_' . time() . '@warga.local';
    
    $stmtUser = $db->prepare("INSERT INTO users (username, password_hash, name, role, email, status) VALUES (?, ?, ?, 'resident', ?, 'active')");
    $stmtUser->execute([$phone, $hashedPassword, $ownerName, $emailToSave]);
    $newUserId = $db->lastInsertId();

    $blockNumber = strtoupper($block) . ' No. ' . $houseNumber;
    $ownerNameWithNote = $ownerName . ' [Daftar Mandiri]';

    $stmtHouse = $db->prepare("INSERT INTO houses (block_number, owner_name, phone, occupancy_status, total_residents, user_id, ktp_image, tenant_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmtHouse->execute([$blockNumber, $ownerNameWithNote, $phone, $occupancyStatus, $totalResidents, $newUserId, $ktpDbPath, $tenantId]);

    $db->commit();

    echo json_encode(['status' => 'success', 'message' => 'Pendaftaran berhasil.']);
    exit();

} catch (Throwable $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Gagal: ' . $e->getMessage()]);
    exit();
}