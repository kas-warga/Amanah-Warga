<?php
use App\Controllers\WhatsappController;

$router->get('/api/whatsapp', [WhatsappController::class, 'index']);
$router->post('/api/whatsapp', [WhatsappController::class, 'store']);
$router->get('/api/whatsapp/{id}', [WhatsappController::class, 'show']);
$router->put('/api/whatsapp/{id}', [WhatsappController::class, 'update']);
$router->delete('/api/whatsapp/{id}', [WhatsappController::class, 'destroy']);
