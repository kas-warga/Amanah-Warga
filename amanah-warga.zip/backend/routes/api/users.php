<?php
use App\Controllers\UsersController;

$router->get('/api/users', [UsersController::class, 'index']);
$router->post('/api/users', [UsersController::class, 'store']);
$router->get('/api/users/{id}', [UsersController::class, 'show']);
$router->put('/api/users/{id}', [UsersController::class, 'update']);
$router->delete('/api/users/{id}', [UsersController::class, 'destroy']);
