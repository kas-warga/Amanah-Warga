<?php
use App\Controllers\ReportsController;

$router->get('/api/reports', [ReportsController::class, 'index']);
$router->post('/api/reports', [ReportsController::class, 'store']);
$router->get('/api/reports/{id}', [ReportsController::class, 'show']);
$router->put('/api/reports/{id}', [ReportsController::class, 'update']);
$router->delete('/api/reports/{id}', [ReportsController::class, 'destroy']);
