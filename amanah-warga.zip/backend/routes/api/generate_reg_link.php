<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    $input = json_decode(file_get_contents("php://input"), true);
    $adminId = $input['admin_id'] ?? '';

    if (empty($adminId)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'ID Admin diperlukan']);
        exit();
    }

    // Kunci Rahasia Sistem (Harus sama dengan yang ada di public_registration.php)
    $secretKey = "AmanahWarga_Secret_2026";
    
    // Set waktu kadaluarsa: Waktu saat ini + 3600 detik (1 Jam)
    $expiresAt = time() + 3600;

    // Racik data: ID Admin digabung dengan Waktu Kadaluarsa
    $payload = $adminId . '|' . $expiresAt;
    
    // Buat tanda tangan digital agar token tidak bisa dipalsukan warga
    $signature = hash_hmac('sha256', $payload, $secretKey);
    
    // Bungkus semua data ke dalam Base64 agar aman ditempel di URL
    $token = base64_encode($payload . '|' . $signature);

    // Hasil akhir link dinamis
    $dynamicLink = "https://bogorvaley.my.id/pendaftaran-warga?ref=" . $token;

    echo json_encode([
        'status' => 'success', 
        'link' => $dynamicLink,
        'expires_at' => date('Y-m-d H:i:s', $expiresAt)
    ]);
    exit();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Gagal membuat link']);
}