<?php
use App\Controllers\ExpensesController;

$router->get('/api/expenses', [ExpensesController::class, 'index']);
$router->post('/api/expenses', [ExpensesController::class, 'store']);
$router->get('/api/expenses/{id}', [ExpensesController::class, 'show']);
$router->put('/api/expenses/{id}', [ExpensesController::class, 'update']);
$router->delete('/api/expenses/{id}', [ExpensesController::class, 'destroy']);
