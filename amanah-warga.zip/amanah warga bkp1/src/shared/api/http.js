import axios from 'axios';

export const http = axios.create({
  baseURL: 'https://bogorvaley.my.id/backend/routes/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

export default http;