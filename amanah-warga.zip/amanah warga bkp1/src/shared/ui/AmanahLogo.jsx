import React from 'react';

export default function AmanahLogo({ className = "w-10 h-10", showSubtitle = true }) {
  return (
    <div className="flex items-center gap-2.5 flex-shrink-0">
      <div className={`relative bg-gradient-to-br from-brand-600 via-brand-500 to-brand-700 rounded-2xl p-2 shadow-md border border-brand-400/30 flex items-center justify-center text-white ${className}`}>
        <svg viewBox="0 0 24 24" className="w-full h-full fill-current" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2 2.5 7.2 12 12l9.5-4.8L12 2Z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" fill="none"/>
          <path d="M2.5 12.2 12 17l9.5-4.8M2.5 17.1 12 22l9.5-4.9" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
        </svg>
      </div>
      {showSubtitle && (
        <div className="flex flex-col text-left leading-tight">
          <span className="font-black text-slate-900 tracking-tight text-sm sm:text-base">Amanah Warga</span>
          <span className="text-[8px] font-bold text-brand-600 tracking-wider uppercase mt-0.5">By. Amanag Group</span>
        </div>
      )}
    </div>
  );
}