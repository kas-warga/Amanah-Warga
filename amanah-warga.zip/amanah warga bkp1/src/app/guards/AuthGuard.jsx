import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../store';

export default function AuthGuard({ allowedRoles }) {
  const { isAuthenticated, user } = useAuthStore();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && user && !allowedRoles.includes(user.role)) {
    // Arahkan ke dashboard yang sesuai jika role tidak diizinkan
    return <Navigate to={user.role === 'admin' ? '/admin' : '/warga'} replace />;
  }

  return <Outlet />;
}