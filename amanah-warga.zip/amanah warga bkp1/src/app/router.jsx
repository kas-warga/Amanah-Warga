import React from 'react';
import { createBrowserRouter, Navigate } from 'react-router-dom';
import AdminLayout from './layouts/AdminLayout';
import LoginPage from '../domains/auth/pages/LoginPage';
import DashboardPage from '../domains/dashboard/pages/DashboardPage';
import ResidentsPage from '../domains/residents/pages/ResidentsPage';
import MasterBillingPage from '../domains/billing/pages/MasterBillingPage';

// 1. Import Halaman Pendaftaran Publik Baru
import RegistrationPage from '../domains/public/pages/RegistrationPage';

const ModulePlaceholder = ({ title, icon }) => (
  // ... (Kode ModulePlaceholder tetap sama seperti yang sudah Anda miliki)
  <div className="p-4 sm:p-6 space-y-4">
    <div className="flex items-center gap-3">
      <span className="text-2xl sm:text-3xl">{icon}</span>
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-slate-900">{title}</h1>
      </div>
    </div>
  </div>
);

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Navigate to="/admin/dashboard" replace />,
  },
  {
    path: '/login',
    element: <LoginPage />,
  },
  // 2. Tambahkan Rute Pendaftaran Publik Disini (Di luar AdminLayout)
  {
    path: '/pendaftaran-warga',
    element: <RegistrationPage />,
  },
  {
    path: '/admin',
    element: <AdminLayout />,
    children: [
      // ... (Seluruh rute admin anak seperti dashboard, warga, master-tagihan tetap sama)
      { index: true, element: <Navigate to="/admin/dashboard" replace /> },
      { path: 'dashboard', element: <DashboardPage /> },
      { path: 'warga', element: <ResidentsPage /> },
      { path: 'master-tagihan', element: <MasterBillingPage /> },
      /* ... sisa menu ... */
    ],
  },
]);

export default router;