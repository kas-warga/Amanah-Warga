import React, { useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';

const navigationModules = [
  {
    category: 'Utama & Hunian',
    items: [
      { name: 'Dashboard Utama', path: '/admin/dashboard', icon: '📊' },
      { name: 'Data Warga & Hunian', path: '/admin/warga', icon: '🏠' },
    ],
  },
  {
    category: 'Keuangan & Tagihan',
    items: [
      { name: 'Master Tagihan', path: '/admin/master-tagihan', icon: '⚙️' },
      { name: 'Billing & Tagihan Warga', path: '/admin/billing', icon: '📜' },
      { name: 'Buku Kas & Transaksi', path: '/admin/kas', icon: '💰' },
      { name: 'Pengeluaran Ops', path: '/admin/pengeluaran', icon: '💸' },
      { name: 'Rekonsiliasi Bank', path: '/admin/rekonsiliasi', icon: '🏦' },
      { name: 'Persetujuan Pembayaran', path: '/admin/persetujuan', icon: '✅' },
      { name: 'QRIS & Payment Gateway', path: '/admin/qris', icon: '📱' },
    ],
  },
  {
    category: 'Layanan Warga',
    items: [
      { name: 'Pendaftaran Warga', path: '/admin/pendaftaran', icon: '📝' },
      { name: 'Pengumuman & Broadcast', path: '/admin/pengumuman', icon: '📢' },
      { name: 'WhatsApp Gateway', path: '/admin/whatsapp', icon: '💬' },
    ],
  },
  {
    category: 'Laporan & Pengaturan',
    items: [
      { name: 'Laporan Keuangan', path: '/admin/laporan', icon: '📈' },
      { name: 'Audit Log & Activity', path: '/admin/audit-log', icon: '🛡️' },
      { name: 'Manajemen User & Akses', path: '/admin/users', icon: '👥' },
      { name: 'Lisensi System', path: '/admin/lisensi', icon: '🔑' },
    ],
  },
];

export default function AdminLayout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col md:flex-row font-sans">
      {/* Sidebar Desktop (Linear Style) */}
      <aside className="hidden md:flex md:w-64 lg:w-72 bg-slate-900 text-slate-300 flex-col justify-between border-r border-slate-800 shrink-0 sticky top-0 h-screen overflow-y-auto">
        <div>
          {/* Logo & Header */}
          <div className="p-5 border-b border-slate-800 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 text-slate-950 font-black text-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
              A
            </div>
            <div>
              <h1 className="font-bold text-white text-base leading-snug">Amanah Warga</h1>
              <span className="text-xs text-slate-400 font-medium">RT 04 / RW 02 Perumahan</span>
            </div>
          </div>

          {/* Navigasi Desktop */}
          <div className="p-4 space-y-6">
            {navigationModules.map((group, idx) => (
              <div key={idx} className="space-y-1.5">
                <span className="text-[10px] font-bold tracking-wider text-slate-500 uppercase px-3">
                  {group.category}
                </span>
                <div className="space-y-1">
                  {group.items.map((item) => {
                    const isActive = location.pathname === item.path || (item.path === '/admin/dashboard' && location.pathname === '/admin');
                    return (
                      <NavLink
                        key={item.path}
                        to={item.path}
                        className={({ isActive: linkActive }) =>
                          `flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-semibold transition ${
                            linkActive || isActive
                              ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                          }`
                        }
                      >
                        <span className="text-sm">{item.icon}</span>
                        <span className="truncate">{item.name}</span>
                      </NavLink>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Profil Admin Desktop */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-full bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 font-bold text-xs flex items-center justify-center shrink-0">
                AD
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">Administrator</p>
                <p className="text-[10px] text-slate-400 truncate">admin@amanah.id</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              title="Keluar"
              className="text-slate-400 hover:text-rose-400 p-1.5 rounded-md hover:bg-slate-800 transition"
            >
              🚪
            </button>
          </div>
        </div>
      </aside>

      {/* Top Header Mobile (Clean & Ringkas) */}
      <header className="md:hidden bg-emerald-700 text-white px-4 py-3 sticky top-0 z-30 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-white text-emerald-800 font-black text-sm flex items-center justify-center shadow-sm">
            A
          </div>
          <div>
            <h1 className="font-bold text-sm leading-tight">Amanah Warga</h1>
            <span className="text-[10px] text-emerald-100 block">RT 04 / RW 02</span>
          </div>
        </div>
        <button
          onClick={() => setIsMobileMenuOpen(true)}
          className="bg-emerald-800/80 hover:bg-emerald-800 border border-emerald-600/50 text-xs px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition text-white shadow-xs"
        >
          <span>⭐</span> Menu (16)
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        <Outlet />
      </main>

      {/* Bottom Action Bar Mobile (Gaya GoPay / DANA) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200 px-3 py-2 z-30 flex items-center justify-around shadow-lg">
        <NavLink
          to="/admin/dashboard"
          className={({ isActive }) =>
            `flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition ${
              isActive ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
            }`
          }
        >
          <span className="text-lg">📊</span>
          <span className="text-[10px]">Beranda</span>
        </NavLink>

        <NavLink
          to="/admin/warga"
          className={({ isActive }) =>
            `flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition ${
              isActive ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
            }`
          }
        >
          <span className="text-lg">👥</span>
          <span className="text-[10px]">Warga</span>
        </NavLink>

        <NavLink
          to="/admin/billing"
          className={({ isActive }) =>
            `flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition ${
              isActive ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
            }`
          }
        >
          <span className="text-lg">📜</span>
          <span className="text-[10px]">Billing</span>
        </NavLink>

        <NavLink
          to="/admin/kas"
          className={({ isActive }) =>
            `flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition ${
              isActive ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
            }`
          }
        >
          <span className="text-lg">💰</span>
          <span className="text-[10px]">Buku Kas</span>
        </NavLink>

        <button
          onClick={() => setIsMobileMenuOpen(true)}
          className="flex flex-col items-center gap-0.5 px-3 py-1 text-slate-500 hover:text-slate-800"
        >
          <span className="text-lg">⭐</span>
          <span className="text-[10px]">Semua</span>
        </button>
      </div>

      {/* Mobile Drawer 16 Modul (Bottom Sheet Drawer) */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-sm animate-fade-in">
          <div
            className="fixed inset-0"
            onClick={() => setIsMobileMenuOpen(false)}
          ></div>
          <div className="bg-slate-900 text-white rounded-t-2xl max-h-[85vh] w-full flex flex-col z-10 shadow-2xl overflow-hidden">
            {/* Header Drawer */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between sticky top-0 bg-slate-900 z-10">
              <div>
                <h3 className="font-bold text-base">Seluruh Menu Sistem (16 Modul)</h3>
                <p className="text-xs text-slate-400">Amanah Warga Admin Platform</p>
              </div>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center font-bold text-slate-300 text-sm"
              >
                ✕
              </button>
            </div>

            {/* Grid Modul */}
            <div className="p-4 overflow-y-auto space-y-6 pb-20">
              {navigationModules.map((group, idx) => (
                <div key={idx} className="space-y-2">
                  <span className="text-[10px] font-bold tracking-wider text-emerald-400 uppercase">
                    {group.category}
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {group.items.map((item) => (
                      <NavLink
                        key={item.path}
                        to={item.path}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={({ isActive }) =>
                          `flex items-center gap-2.5 p-3 rounded-xl border text-xs font-semibold transition ${
                            isActive
                              ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-bold shadow-md'
                              : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700/60 text-slate-200'
                          }`
                        }
                      >
                        <span className="text-lg">{item.icon}</span>
                        <span className="truncate">{item.name}</span>
                      </NavLink>
                    ))}
                  </div>
                </div>
              ))}

              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <div className="text-xs text-slate-400">
                  Logged in as <span className="text-white font-bold">Admin</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="bg-rose-500/20 text-rose-300 border border-rose-500/30 px-3 py-1.5 rounded-lg text-xs font-bold"
                >
                  Keluar Akun
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}