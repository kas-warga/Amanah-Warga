import React from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import { Home, Users, LogOut, FileText, Settings, Menu } from 'lucide-react';
import { useAuthStore } from '../../app/store';

export default function AdminLayout() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans">
      {/* Sidebar */}
      <aside className="w-64 bg-brand-900 text-white flex flex-col shadow-xl">
        <div className="p-6 border-b border-white/10">
          <h1 className="text-xl font-black tracking-wide text-white">
            Amanah<span className="text-emerald-400">Warga</span>
          </h1>
          <p className="text-xs text-brand-300 mt-1">Portal Pengurus</p>
        </div>
        
        <nav className="flex-1 py-6 px-3 space-y-1">
          <Link to="/admin" className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-white/10 text-white font-semibold text-sm transition">
            <Home className="w-5 h-5" /> Dashboard
          </Link>
          <Link to="/admin/warga" className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-white/5 text-brand-200 hover:text-white font-semibold text-sm transition">
            <Users className="w-5 h-5" /> Data Warga
          </Link>
          <Link to="/admin/kas" className="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-white/5 text-brand-200 hover:text-white font-semibold text-sm transition">
            <FileText className="w-5 h-5" /> Keuangan & Kas
          </Link>
        </nav>

        <div className="p-4 border-t border-white/10">
          <button 
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg hover:bg-rose-500/20 text-rose-300 hover:text-rose-200 font-semibold text-sm transition"
          >
            <LogOut className="w-5 h-5" /> Keluar Sistem
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-slate-200 h-16 flex items-center justify-between px-8 z-10">
          <button className="lg:hidden text-slate-500 hover:text-slate-700">
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex-1" /> {/* Spacer */}
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-slate-700">{user?.name || 'Admin'}</p>
              <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">{user?.role}</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold border border-brand-200">
              {user?.name?.charAt(0) || 'A'}
            </div>
          </div>
        </header>

        {/* Dynamic Content (Outlet) */}
        <div className="flex-1 overflow-auto p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}