import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import http from '../../../shared/api/http';

export default function LoginPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  
  // State untuk fitur lihat kata sandi
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    try {
      const response = await http.post('/auth/login.php', {
        username: formData.username,
        password: formData.password,
      });

      if (response.data && response.data.status === 'success') {
        localStorage.setItem('token', response.data.data.token);
        localStorage.setItem('user', JSON.stringify(response.data.data));
        navigate('/admin/dashboard', { replace: true });
      } else {
        setErrorMsg(response.data?.message || 'Gagal melakukan login.');
      }
    } catch (err) {
      setErrorMsg(
        err.response?.data?.message || 
        'Koneksi ke server gagal. Periksa jaringan atau hubungi admin.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 sm:p-6 font-sans">
      <div className="w-full max-w-md">
        {/* Logo & Header */}
        <div className="text-center mb-8 space-y-2">
          <div className="w-16 h-16 bg-emerald-500 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black text-3xl">
            A
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Amanah Warga</h1>
          <p className="text-sm text-slate-500 font-medium">Sistem Manajemen Terpadu RT/RW</p>
        </div>

        {/* Card Form Login */}
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
          <h2 className="text-lg font-bold text-slate-800 mb-6">Masuk ke Akun Anda</h2>

          {errorMsg && (
            <div className="mb-5 p-3 sm:p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
              <span className="text-rose-600 text-lg leading-none">⚠️</span>
              <p className="text-xs sm:text-sm font-medium text-rose-700 leading-snug">
                {errorMsg}
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                Username / No. WhatsApp
              </label>
              <input
                type="text"
                required
                placeholder="Masukkan No. WhatsApp / Username"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
                autoComplete="username"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                Kata Sandi
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition pr-16"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-emerald-600 font-bold text-[10px] transition"
                >
                  {showPassword ? "SEMBUNYI" : "LIHAT"}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className={`w-full py-3.5 mt-2 rounded-xl text-sm font-bold text-white shadow-lg transition-all flex items-center justify-center gap-2 ${
                loading 
                  ? 'bg-emerald-400 shadow-none cursor-not-allowed' 
                  : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/30 hover:shadow-emerald-600/50 hover:-translate-y-0.5'
              }`}
            >
              {loading ? 'Memproses...' : 'Masuk Sekarang ➔'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}