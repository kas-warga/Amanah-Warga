import React, { useState, useEffect } from 'react';
import http from '../../../shared/api/http';

const typeLabels = {
  monthly: { label: 'Rutin Bulanan', color: 'bg-emerald-100 text-emerald-800' },
  one_time: { label: 'Satu Kali', color: 'bg-blue-100 text-blue-800' },
  incidental: { label: 'Insidental', color: 'bg-amber-100 text-amber-800' },
};

export default function MasterBillingPage() {
  const [billings, setBillings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    amount: '',
    billing_type: 'monthly',
    description: '',
  });

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await http.get('/billings.php');
      if (res.data && res.data.status === 'success') {
        setBillings(res.data.data || []);
      }
    } catch (err) {
      console.error('Gagal memuat master tagihan:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await http.post('/billings.php', formData);
      if (res.data && res.data.status === 'success') {
        setIsModalOpen(false);
        setFormData({ title: '', amount: '', billing_type: 'monthly', description: '' });
        await loadData();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Gagal menyimpan master tagihan');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Hapus jenis tagihan ini?')) return;
    try {
      await http.delete(`/billings.php?id=${id}`);
      await loadData();
    } catch (err) {
      alert('Gagal menghapus data');
    }
  };

  const formatRupiah = (val) =>
    new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(val);

  return (
    <div className="p-4 sm:p-6 space-y-5 pb-28 md:pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">Master Jenis Tagihan</h1>
          <p className="text-xs sm:text-sm text-slate-500">Kelola daftar iuran standar warga RT</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl font-bold text-sm transition shadow-sm"
        >
          + Tambah Jenis Tagihan
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-slate-400 text-xs">Memuat data master tagihan...</div>
        ) : billings.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">Belum ada master tagihan tersimpan.</div>
        ) : (
          <div className="divide-y divide-slate-100">
            {billings.map((item) => {
              const type = typeLabels[item.billing_type] || typeLabels.monthly;
              return (
                <div key={item.id} className="p-4 flex items-center justify-between gap-3 hover:bg-slate-50 transition">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-900 text-sm">{item.title}</h4>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${type.color}`}>
                        {type.label}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500">{item.description || 'Tidak ada keterangan'}</p>
                  </div>
                  <div className="text-right flex items-center gap-3">
                    <span className="text-sm font-black text-slate-900">{formatRupiah(item.amount)}</span>
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="text-xs text-rose-600 hover:bg-rose-50 p-2 rounded-lg font-bold"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm p-0 sm:p-4">
          <div className="bg-white w-full sm:max-w-md rounded-t-2xl sm:rounded-2xl p-5 sm:p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-slate-900">Tambah Master Tagihan</h3>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Nama Tagihan</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Iuran Kebersihan & Keamanan"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3.5 py-2.5 border rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Nominal Standard (Rp)</label>
                <input
                  type="number"
                  required
                  placeholder="150000"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full px-3.5 py-2.5 border rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Tipe Tagihan</label>
                <select
                  value={formData.billing_type}
                  onChange={(e) => setFormData({ ...formData, billing_type: e.target.value })}
                  className="w-full px-3.5 py-2.5 border rounded-xl text-xs sm:text-sm bg-white"
                >
                  <option value="monthly">Rutin Bulanan</option>
                  <option value="one_time">Satu Kali</option>
                  <option value="incidental">Insidental</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Keterangan Opsional</label>
                <textarea
                  rows="2"
                  placeholder="Deskripsi singkat iuran..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3.5 py-2.5 border rounded-xl text-xs sm:text-sm"
                ></textarea>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border rounded-xl text-xs font-bold text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700"
                >
                  Simpan Master
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}