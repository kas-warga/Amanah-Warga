import React, { useState } from 'react';
import http from '../../../shared/api/http';

export default function RegistrationPage() {
  const [formData, setFormData] = useState({
    block: '',
    house_number: '',
    owner_name: '',
    phone_number: '',
    email: '',
    password: '',
    occupancy_status: 'occupied',
    total_residents: 1,
    notes: '',
  });
  
  // State khusus untuk file KTP
  const [ktpFile, setKtpFile] = useState(null);
  
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    if (!ktpFile) {
      setErrorMsg('Mohon unggah foto KTP Anda.');
      setLoading(false);
      return;
    }

    try {
      // Menggunakan FormData karena kita mengirim file (gambar)
      const dataToSend = new FormData();
      Object.keys(formData).forEach(key => {
        dataToSend.append(key, formData[key]);
      });
      dataToSend.append('ktp_image', ktpFile);

      const response = await http.post('/public_registration.php', dataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      if (response.data && response.data.status === 'success') {
        setIsSuccess(true);
      } else {
        setErrorMsg(response.data?.message || 'Gagal mengirim data pendaftaran.');
      }
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Koneksi ke server gagal. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white max-w-md w-full p-8 rounded-3xl shadow-xl text-center space-y-4 border border-slate-100">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto text-4xl font-black mb-2">
            ✓
          </div>
          <h2 className="text-2xl font-black text-slate-800">Pendaftaran Berhasil!</h2>
          <p className="text-slate-500 text-sm leading-relaxed">
            Terima kasih, data hunian Anda telah masuk ke sistem <strong>RT 04 / RW 02</strong>. Akun Warga Anda sudah aktif.
          </p>
          <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 text-left my-4">
            <p className="text-xs font-bold text-emerald-800 mb-2">Informasi Login Akun Warga:</p>
            <p className="text-sm text-emerald-700">Username: <span className="font-bold bg-white px-2 py-0.5 rounded">{formData.phone_number}</span></p>
            <p className="text-sm text-emerald-700 mt-1">Kata Sandi: <span className="italic">(Seperti yang Anda buat)</span></p>
          </div>
          <div className="flex gap-2 justify-center mt-6">
            <button 
              onClick={() => window.location.href = '/login'}
              className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-emerald-700 transition w-full"
            >
              Lanjut ke Halaman Login ➔
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 flex justify-center">
      <div className="max-w-md w-full space-y-6">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-emerald-500 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black text-3xl">
            A
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Pendaftaran Warga</h1>
          <p className="text-sm text-slate-500 font-medium bg-emerald-50 text-emerald-700 inline-block px-3 py-1 rounded-full border border-emerald-100 mt-2">
            Khusus Lingkungan RT 04 / RW 02
          </p>
        </div>

        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
          {errorMsg && (
            <div className="mb-5 p-3 sm:p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
              <span className="text-rose-600 text-lg leading-none">⚠️</span>
              <p className="text-xs sm:text-sm font-medium text-rose-700 leading-snug">{errorMsg}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Blok Rumah</label>
                <input
                  type="text" required placeholder="Cth: A"
                  value={formData.block} onChange={(e) => setFormData({ ...formData, block: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Nomor Rumah</label>
                <input
                  type="text" required placeholder="Cth: 12"
                  value={formData.house_number} onChange={(e) => setFormData({ ...formData, house_number: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Nama Lengkap Sesuai KTP</label>
              <input
                type="text" required placeholder="Nama Lengkap"
                value={formData.owner_name} onChange={(e) => setFormData({ ...formData, owner_name: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* FOTO KTP */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 border-dashed">
              <label className="block text-xs font-bold text-slate-700 mb-2">Unggah Foto KTP (Wajib)</label>
              <input
                type="file" required accept="image/*"
                onChange={(e) => setKtpFile(e.target.files[0])}
                className="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100"
              />
              <p className="text-[10px] text-slate-400 mt-2">*Format JPG/PNG. Pastikan foto KTP terlihat jelas untuk verifikasi keamanan lingkungan.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-emerald-700 mb-1.5">No. WhatsApp (Username)</label>
                <input
                  type="text" required placeholder="081234..."
                  value={formData.phone_number} onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Email (Opsional)</label>
                <input
                  type="email" placeholder="contoh@email.com"
                  value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Buat Kata Sandi Akun</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"} required placeholder="Minimal 6 karakter"
                  value={formData.password} onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 pr-16"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-emerald-600 font-bold text-[10px]"
                >
                  {showPassword ? "SEMBUNYI" : "LIHAT"}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Jumlah Jiwa</label>
                <input
                  type="number" min="1" required
                  value={formData.total_residents} onChange={(e) => setFormData({ ...formData, total_residents: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Status Hunian</label>
                <select
                  value={formData.occupancy_status} onChange={(e) => setFormData({ ...formData, occupancy_status: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="occupied">Milik Pribadi (Dihuni)</option>
                  <option value="rented">Sewa / Kontrak</option>
                  <option value="other">Lainnya</option>
                </select>
              </div>
            </div>

            <button
              type="submit" disabled={loading}
              className="w-full py-3.5 mt-4 rounded-xl text-sm font-bold text-white shadow-lg bg-emerald-600 hover:bg-emerald-700 hover:-translate-y-0.5 transition-all"
            >
              {loading ? 'Mengirim Data & KTP...' : 'Kirim Data Pendataan ➔'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}