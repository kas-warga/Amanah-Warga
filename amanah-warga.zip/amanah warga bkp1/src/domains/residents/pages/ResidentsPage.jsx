import React, { useState, useEffect } from 'react';
import http from '../../../shared/api/http';

export default function ResidentsPage() {
  const [residents, setResidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchResidents = async () => {
    try {
      setLoading(true);
      const response = await http.get('/houses.php');
      if (response.data && response.data.status === 'success') {
        setResidents(response.data.data);
      }
    } catch (error) {
      console.error("Gagal memuat data warga", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResidents();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Apakah Anda yakin ingin menonaktifkan/menghapus data warga ini?')) return;
    
    try {
      const response = await http.delete(`/houses.php?id=${id}`);
      if (response.data && response.data.status === 'success') {
        alert(response.data.message);
        fetchResidents();
      }
    } catch (error) {
      alert(error.response?.data?.message || 'Gagal memproses permintaan.');
    }
  };

  const filteredResidents = residents.filter(res => 
    res.owner_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    res.block.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 sm:p-6 space-y-6 bg-slate-50/50 min-h-screen pb-24">
      <div>
        <h1 className="text-xl font-bold text-slate-900">Data Warga & Hunian</h1>
        <p className="text-sm text-slate-500">Kelola informasi hunian, pemilik rumah, kontak warga, dan KTP</p>
      </div>

      <button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2">
        <span>+</span> Tambah Warga Baru
      </button>

      <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-sm">
        <input 
          type="text" 
          placeholder="Cari nama warga, blok, atau nomor rumah..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-2 outline-none text-sm bg-transparent"
        />
      </div>

      <div className="space-y-4">
        {loading ? (
          <div className="text-center text-slate-500 text-sm py-8">Memuat data...</div>
        ) : filteredResidents.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center text-slate-500 text-sm">
            Data warga tidak ditemukan.
          </div>
        ) : (
          filteredResidents.map((res) => (
            <div key={res.id} className={`bg-white rounded-2xl border ${res.user_status === 'inactive' ? 'border-rose-200 opacity-75' : 'border-slate-200'} p-4 flex gap-4 shadow-sm relative transition-all flex-col sm:flex-row`}>
              
              <div className="flex gap-4 w-full">
                <div className="w-16 h-16 shrink-0 bg-emerald-50 text-emerald-700 font-black text-xs flex items-center justify-center text-center rounded-xl break-words p-1 border border-emerald-100">
                  {res.block}
                </div>

                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-slate-800 truncate text-sm">{res.owner_name}</h3>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${res.user_status === 'inactive' ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>
                        {res.user_status === 'inactive' ? 'Non-Aktif' : (res.occupancy_status === 'occupied' ? 'Dihuni' : res.occupancy_status)}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1 truncate">
                      Total {res.total_residents} Jiwa • {res.phone_number || '-'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 mt-3 flex-wrap">
                    {/* Tombol Lihat KTP muncul jika data KTP ada */}
                    {res.ktp_image && (
                      <button 
                        onClick={() => window.open(`https://bogorvaley.my.id/backend/${res.ktp_image}`, '_blank')}
                        className="text-xs font-bold text-blue-600 bg-blue-50 border border-blue-200 px-3 py-1.5 rounded-lg flex items-center gap-1 hover:bg-blue-100 transition"
                      >
                        🪪 Lihat KTP
                      </button>
                    )}
                    
                    <button 
                      disabled={res.user_status === 'inactive'}
                      className={`text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 transition ${res.user_status === 'inactive' ? 'text-slate-400 bg-slate-50 border border-slate-200 cursor-not-allowed' : 'text-emerald-600 bg-emerald-50 border border-emerald-200 hover:bg-emerald-100'}`}
                    >
                      💬 WA
                    </button>
                    <button className="text-xs font-bold text-amber-600 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-lg flex items-center gap-1 hover:bg-amber-100 transition">
                      ✏️ Edit
                    </button>
                    <button 
                      onClick={() => handleDelete(res.id)}
                      className="text-xs text-slate-500 hover:text-rose-600 hover:bg-rose-50 p-1.5 rounded-lg transition ml-auto"
                      title={res.user_status === 'inactive' ? 'Warga sudah Non-Aktif' : 'Nonaktifkan Warga'}
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              </div>

            </div>
          ))
        )}
      </div>
    </div>
  );
}