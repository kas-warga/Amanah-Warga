import http from '../../shared/api/http';

export const fetchResidents = async () => {
  try {
    const response = await http.get('/houses.php');
    if (response.data && response.data.status === 'success') {
      return {
        status: 'success',
        data: Array.isArray(response.data.data) ? response.data.data : [],
      };
    }
    return {
      status: 'error',
      data: [],
      message: response.data?.message || 'Gagal memuat data warga',
    };
  } catch (error) {
    console.error('Error fetching residents:', error);
    return { status: 'error', data: [], message: error.message };
  }
};

export const createResident = async (data) => {
  try {
    const response = await http.post('/houses.php', data);
    return response.data;
  } catch (error) {
    console.error('Error creating resident:', error);
    throw error;
  }
};

export const updateResident = async (id, data) => {
  try {
    const response = await http.put(`/houses.php?id=${id}`, data);
    return response.data;
  } catch (error) {
    console.error('Error updating resident:', error);
    throw error;
  }
};

export const deleteResident = async (id) => {
  try {
    const response = await http.delete(`/houses.php?id=${id}`);
    return response.data;
  } catch (error) {
    console.error('Error deleting resident:', error);
    throw error;
  }
};