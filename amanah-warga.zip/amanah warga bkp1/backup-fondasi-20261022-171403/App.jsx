import { Link, Navigate, Route, Routes } from "react-router-dom";
import { ShieldCheck, Wallet, Users, ArrowRight } from "lucide-react";

function HomePage() {
  return (
    <main className="min-h-screen px-5 py-10 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <header className="flex items-center gap-3">
          <div className="rounded-xl bg-green-800 p-3 text-white">
            <ShieldCheck size={28} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-green-900">
              Amanah Warga
            </h1>
            <p className="text-sm text-gray-500">
              Administrasi warga yang transparan
            </p>
          </div>
        </header>

        <section className="mt-12 rounded-3xl bg-green-900 p-7 text-white sm:p-10">
          <p className="text-sm font-semibold uppercase tracking-wider text-green-200">
            Fondasi aplikasi
          </p>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">
            Kelola kas warga dengan lebih amanah.
          </h2>
          <p className="mt-4 max-w-2xl leading-7 text-green-100">
            Kerangka awal Amanah Warga sedang dibangun. Berikutnya kita akan
            menghubungkan modul aplikasi dengan backend PHP dan database MySQL.
          </p>
          <div className="mt-7 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 font-semibold text-green-900">
            Fondasi frontend aktif <ArrowRight size={18} />
          </div>
        </section>

        <section className="mt-8 grid gap-4 sm:grid-cols-3">
          <div className="rounded-2xl border border-gray-200 bg-white p-5">
            <Wallet className="text-green-800" size={25} />
            <h3 className="mt-4 font-bold">Buku Kas</h3>
            <p className="mt-2 text-sm leading-6 text-gray-600">
              Pencatatan pemasukan, pengeluaran, dan saldo.
            </p>
          </div>

          <div className="rounded-2xl border border-gray-200 bg-white p-5">
            <Users className="text-green-800" size={25} />
            <h3 className="mt-4 font-bold">Data Warga</h3>
            <p className="mt-2 text-sm leading-6 text-gray-600">
              Fondasi pengelolaan anggota dan rumah.
            </p>
          </div>

          <div className="rounded-2xl border border-gray-200 bg-white p-5">
            <ShieldCheck className="text-green-800" size={25} />
            <h3 className="mt-4 font-bold">Akses Terstruktur</h3>
            <p className="mt-2 text-sm leading-6 text-gray-600">
              Fondasi pengaturan akses admin dan warga.
            </p>
          </div>
        </section>

        <footer className="mt-10 text-center text-sm text-gray-500">
          Amanah Warga · Tahap pembangunan fondasi
        </footer>
      </div>
    </main>
  );
}

function NotFoundPage() {
  return (
    <main className="p-10 text-center">
      <h1 className="text-2xl font-bold">Halaman tidak ditemukan</h1>
      <Link className="mt-4 inline-block text-green-800 underline" to="/">
        Kembali ke beranda
      </Link>
    </main>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/start" element={<Navigate to="/" replace />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}