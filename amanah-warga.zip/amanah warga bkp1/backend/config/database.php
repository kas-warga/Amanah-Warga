<?php
// Pastikan file ini tidak ada spasi kosong sebelum tulisan <?php

function getDbConnection() {
    $host = 'localhost';
    $dbname = 'u551731585_amanah'; 
    $username = 'u551731585_warga'; 
    
    // ⚠️ SANGAT PENTING: PASTIKAN PASSWORD INI DIGANTI DENGAN PASSWORD DATABASE ASLI HOSTINGER ANDA
    $password = 'S@lsabila1'; 

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        
        return $pdo;
    } catch (PDOException $e) {
        // Keluarkan output Error berformat JSON agar frontend tidak salah tangkap
        http_response_code(500);
        header("Content-Type: application/json; charset=UTF-8");
        echo json_encode([
            'status' => 'error', 
            'message' => 'Koneksi Database Gagal. Silakan cek Username/Password di database.php. Detail: ' . $e->getMessage()
        ]);
        exit();
    }
}