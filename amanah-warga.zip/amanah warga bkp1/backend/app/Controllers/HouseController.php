<?php
namespace App\Controllers;

class HouseController {
    private $db;

    public function __construct($dbConnection) {
        $this->db = $dbConnection;
    }

    // GET /api/houses (Mendapatkan semua data warga & hunian)
    public function index() {
        $stmt = $this->db->query("
            SELECT h.*, u.email 
            FROM houses h 
            LEFT JOIN users u ON h.user_id = u.id 
            ORDER BY h.block_number ASC
        ");
        $houses = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        echo json_encode(['status' => 'success', 'data' => $houses]);
    }

    // POST /api/houses (Menambah data warga & hunian baru)
    public function store() {
        $data = json_decode(file_get_contents("php://input"), true);

        $query = "INSERT INTO houses (block_number, owner_name, phone, occupancy_status, total_residents, user_id) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($query);
        $success = $stmt->execute([
            $data['block_number'],
            $data['owner_name'],
            $data['phone'] ?? null,
            $data['occupancy_status'] ?? 'occupied',
            $data['total_residents'] ?? 1,
            $data['user_id'] ?? null
        ]);

        echo json_encode([
            'status' => $success ? 'success' : 'error',
            'message' => $success ? 'Data warga berhasil ditambahkan' : 'Gagal menyimpan data'
        ]);
    }
}