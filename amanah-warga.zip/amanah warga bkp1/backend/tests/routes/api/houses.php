<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

ini_set('display_errors', '0');
error_reporting(E_ALL);

try {
    $configPath = __DIR__ . '/../../config/database.php';
    if (!file_exists($configPath)) {
        throw new Exception("File database.php tidak ditemukan pada path: " . $configPath);
    }
    require_once $configPath;

    $db = getDbConnection();
    if (!$db) {
        throw new Exception("Koneksi database PDO gagal");
    }

    // Pastikan struktur tabel houses valid
    $db->exec("CREATE TABLE IF NOT EXISTS houses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        block VARCHAR(20) NOT NULL,
        house_number VARCHAR(20) NOT NULL,
        owner_name VARCHAR(150) NOT NULL,
        phone_number VARCHAR(30) NULL,
        occupancy_status ENUM('occupied', 'vacant', 'rented', 'other') DEFAULT 'occupied',
        total_residents INT DEFAULT 1,
        notes TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $stmt = $db->query("SELECT * FROM houses ORDER BY block ASC, CAST(house_number AS UNSIGNED) ASC, house_number ASC");
        $houses = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Sanitasi tipe data output
        $formatted = array_map(function($item) {
            return [
                'id' => (int)$item['id'],
                'block' => (string)($item['block'] ?? ''),
                'house_number' => (string)($item['house_number'] ?? ''),
                'owner_name' => (string)($item['owner_name'] ?? 'Tanpa Nama'),
                'phone_number' => (string)($item['phone_number'] ?? ''),
                'occupancy_status' => (string)($item['occupancy_status'] ?? 'vacant'),
                'total_residents' => (int)($item['total_residents'] ?? 0),
                'notes' => (string)($item['notes'] ?? ''),
                'created_at' => $item['created_at'] ?? null
            ];
        }, $houses ?: []);

        echo json_encode(['status' => 'success', 'data' => $formatted]);
        exit();
    }

    if ($method === 'POST') {
        $input = json_decode(file_get_contents("php://input"), true);

        if (empty($input['block']) || empty($input['house_number']) || empty($input['owner_name'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Blok, Nomor Rumah, dan Nama Pemilik wajib diisi']);
            exit();
        }

        $stmt = $db->prepare("INSERT INTO houses (block, house_number, owner_name, phone_number, occupancy_status, total_residents, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            strtoupper(trim($input['block'])),
            trim($input['house_number']),
            trim($input['owner_name']),
            trim($input['phone_number'] ?? ''),
            $input['occupancy_status'] ?? 'occupied',
            (int)($input['total_residents'] ?? 1),
            trim($input['notes'] ?? '')
        ]);

        echo json_encode(['status' => 'success', 'message' => 'Data warga berhasil ditambahkan', 'id' => $db->lastInsertId()]);
        exit();
    }

    if ($method === 'PUT') {
        $input = json_decode(file_get_contents("php://input"), true);
        $id = isset($_GET['id']) ? (int)$_GET['id'] : (int)($input['id'] ?? 0);

        if (!$id) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'ID data tidak ditemukan']);
            exit();
        }

        $stmt = $db->prepare("UPDATE houses SET block = ?, house_number = ?, owner_name = ?, phone_number = ?, occupancy_status = ?, total_residents = ?, notes = ? WHERE id = ?");
        $stmt->execute([
            strtoupper(trim($input['block'])),
            trim($input['house_number']),
            trim($input['owner_name']),
            trim($input['phone_number'] ?? ''),
            $input['occupancy_status'] ?? 'occupied',
            (int)($input['total_residents'] ?? 1),
            trim($input['notes'] ?? ''),
            $id
        ]);

        echo json_encode(['status' => 'success', 'message' => 'Data warga berhasil diperbarui']);
        exit();
    }

    if ($method === 'DELETE') {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'ID data tidak ditemukan']);
            exit();
        }

        $stmt = $db->prepare("DELETE FROM houses WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(['status' => 'success', 'message' => 'Data warga berhasil dihapus']);
        exit();
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit();
}