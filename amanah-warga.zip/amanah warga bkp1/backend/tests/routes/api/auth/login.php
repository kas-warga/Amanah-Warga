<?php

require_once '../../../config/database.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Metode tidak diizinkan.'
    ]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$email = trim($data['email'] ?? '');
$password = $data['password'] ?? '';

if ($email === '' || $password === '') {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Email dan password wajib diisi.'
    ]);
    exit;
}

$stmt = $conn->prepare(
    'SELECT id, name, role, password_hash, status
     FROM users
     WHERE email = :email
     LIMIT 1'
);

$stmt->execute(['email' => $email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => 'Email atau password tidak valid.'
    ]);
    exit;
}

if ($user['status'] !== 'active') {
    http_response_code(403);
    echo json_encode([
        'status' => 'error',
        'message' => 'Akun belum aktif atau aksesnya sedang dibatasi.'
    ]);
    exit;
}

session_regenerate_id(true);

$_SESSION['user_id'] = (int) $user['id'];
$_SESSION['role'] = $user['role'];

echo json_encode([
    'status' => 'success',
    'message' => 'Login berhasil.',
    'data' => [
        'id' => (int) $user['id'],
        'name' => $user['name'],
        'role' => $user['role']
    ]
]);