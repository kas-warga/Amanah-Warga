<?php
require 'config/database.php';
$hash = password_hash('admin123', PASSWORD_DEFAULT);
$conn->query("UPDATE users SET password_hash = '$hash' WHERE email = 'admin@amanah.com'");
echo "Sukses memperbaiki password admin!";