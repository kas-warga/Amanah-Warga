<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

ini_set('display_errors', '0');
error_reporting(E_ALL);

try {
    $configPath = __DIR__ . '/../../config/database.php';
    if (!file_exists($configPath)) {
        throw new Exception("File database.php tidak ditemukan");
    }
    require_once $configPath;

    $db = getDbConnection();
    if (!$db) {
        throw new Exception("Koneksi database gagal");
    }

    // Buat tabel transactions jika belum ada
    $db->exec("CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(200) NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        type ENUM('income', 'expense') NOT NULL,
        category VARCHAR(100) DEFAULT 'Umum',
        party_name VARCHAR(150) NULL,
        transaction_date DATE NOT NULL,
        description TEXT NULL,
        is_manual TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        // Ambil histori aktivitas transaksi
        $stmt = $db->query("SELECT * FROM transactions ORDER BY transaction_date DESC, id DESC LIMIT 20");
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Hitung Ringkasan Kas
        $stmtIncome = $db->query("SELECT SUM(amount) as total FROM transactions WHERE type = 'income'");
        $totalIncome = (float)($stmtIncome->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);

        $stmtExpense = $db->query("SELECT SUM(amount) as total FROM transactions WHERE type = 'expense'");
        $totalExpense = (float)($stmtExpense->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);

        $totalKas = $totalIncome - $totalExpense;

        // Hitung Pemasukan & Pengeluaran Bulan Ini
        $currentMonth = date('Y-m');
        $stmtIncMonth = $db->prepare("SELECT SUM(amount) as total FROM transactions WHERE type = 'income' AND DATE_FORMAT(transaction_date, '%Y-%m') = ?");
        $stmtIncMonth->execute([$currentMonth]);
        $incMonth = (float)($stmtIncMonth->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);

        $stmtExpMonth = $db->prepare("SELECT SUM(amount) as total FROM transactions WHERE type = 'expense' AND DATE_FORMAT(transaction_date, '%Y-%m') = ?");
        $stmtExpMonth->execute([$currentMonth]);
        $expMonth = (float)($stmtExpMonth->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);

        echo json_encode([
            'status' => 'success',
            'summary' => [
                'totalKas' => $totalKas,
                'pemasukanBulanIni' => $incMonth,
                'pengeluaranBulanIni' => $expMonth,
            ],
            'data' => $transactions
        ]);
        exit();
    }

    if ($method === 'POST') {
        $input = json_decode(file_get_contents("php://input"), true);

        if (empty($input['title']) || empty($input['amount']) || empty($input['type'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Judul, nominal, dan tipe transaksi wajib diisi']);
            exit();
        }

        $stmt = $db->prepare("INSERT INTO transactions (title, amount, type, category, party_name, transaction_date, description, is_manual) VALUES (?, ?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([
            trim($input['title']),
            (float)$input['amount'],
            $input['type'],
            trim($input['category'] ?? 'Lain-Lain'),
            trim($input['party_name'] ?? '-'),
            $input['transaction_date'] ?? date('Y-m-d'),
            trim($input['description'] ?? '')
        ]);

        echo json_encode(['status' => 'success', 'message' => 'Transaksi berhasil dicatat']);
        exit();
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit();
}