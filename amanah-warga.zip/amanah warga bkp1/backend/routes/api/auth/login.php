<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

ini_set('display_errors', '0');
error_reporting(E_ALL);

try {
    $configPath = __DIR__ . '/../../../config/database.php';
    if (!file_exists($configPath)) {
        throw new Exception("File database.php tidak ditemukan");
    }
    require_once $configPath;

    $db = getDbConnection();
    if (!$db) throw new Exception("Koneksi database gagal");

    // Pastikan akun admin default tersedia (Menyesuaikan dengan nama kolom tabel Anda)
    $stmtCheck = $db->query("SELECT COUNT(*) FROM users WHERE username = 'admin'");
    if ($stmtCheck->fetchColumn() == 0) {
        $defaultPass = password_hash('password123', PASSWORD_DEFAULT);
        // Kita isi email dummy & status active agar tidak ditolak oleh MySQL
        $stmtInsert = $db->prepare("INSERT INTO users (username, password_hash, name, role, email, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmtInsert->execute(['admin', $defaultPass, 'Administrator RT', 'admin', 'admin@rt04.local', 'active']);
    }

    // Tangkap data yang dikirim dari React
    $input = json_decode(file_get_contents("php://input"), true);
    $username = trim($input['username'] ?? $_POST['username'] ?? '');
    $password = trim($input['password'] ?? $_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Username dan password wajib diisi.']);
        exit();
    }

    // Eksekusi Login mencari username
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $isValid = false;
    if ($user) {
        // Cek password menggunakan kolom 'password_hash' dari tabel Anda
        if (password_verify($password, $user['password_hash']) || $password === $user['password_hash']) {
            $isValid = true;
        }
    }

    if (!$isValid) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Username atau password salah']);
        exit();
    }

    // Cek jika akun di-lock/pending (sesuai struktur tabel Anda)
    if (isset($user['status']) && $user['status'] !== 'active') {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Akun Anda berstatus ' . $user['status'] . '. Hubungi Super Admin.']);
        exit();
    }

    // Login Berhasil
    echo json_encode([
        'status' => 'success',
        'message' => 'Login berhasil',
        'data' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'name' => $user['name'],
            'role' => $user['role'],
            'token' => 'mock-jwt-token-amanah-' . $user['id']
        ]
    ]);
    exit();

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Internal Server Error: ' . $e->getMessage()]);
    exit();
}