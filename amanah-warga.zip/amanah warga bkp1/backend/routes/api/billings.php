<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

ini_set('display_errors', '0');
error_reporting(E_ALL);

try {
    $configPath = __DIR__ . '/../../config/database.php';
    if (!file_exists($configPath)) {
        throw new Exception("File database.php tidak ditemukan");
    }
    require_once $configPath;

    $db = getDbConnection();
    if (!$db) {
        throw new Exception("Koneksi database gagal");
    }

    // Buat/Sesuaikan struktur tabel billings agar mendukung VARCHAR custom
    $db->exec("CREATE TABLE IF NOT EXISTS billings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(150) NOT NULL,
        amount DECIMAL(12,2) NOT NULL DEFAULT 0,
        billing_type VARCHAR(50) NOT NULL DEFAULT 'monthly',
        description TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Otomatis ubah tipe kolom jika sebelumnya terbuat sebagai ENUM
    try {
        $db->exec("ALTER TABLE billings MODIFY COLUMN billing_type VARCHAR(50) NOT NULL DEFAULT 'monthly';");
    } catch (Throwable $e) {
        // Abaikan jika kolom sudah berjenis VARCHAR
    }

    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $stmt = $db->query("SELECT * FROM billings ORDER BY id DESC");
        $billings = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['status' => 'success', 'data' => $billings]);
        exit();
    }

    if ($method === 'POST') {
        $input = json_decode(file_get_contents("php://input"), true);

        if (empty($input['title']) || !isset($input['amount'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Judul tagihan dan nominal wajib diisi']);
            exit();
        }

        $stmt = $db->prepare("INSERT INTO billings (title, amount, billing_type, description) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            trim($input['title']),
            (float)$input['amount'],
            trim($input['billing_type'] ?? 'monthly'),
            trim($input['description'] ?? '')
        ]);

        echo json_encode(['status' => 'success', 'message' => 'Master tagihan berhasil disimpan', 'id' => $db->lastInsertId()]);
        exit();
    }

    if ($method === 'DELETE') {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'ID tidak valid']);
            exit();
        }

        $stmt = $db->prepare("DELETE FROM billings WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(['status' => 'success', 'message' => 'Master tagihan berhasil dihapus']);
        exit();
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit();
}