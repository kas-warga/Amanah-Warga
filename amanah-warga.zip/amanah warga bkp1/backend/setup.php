<?php
require_once 'config/database.php';

$email = 'admin@amanah.com';
$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);

try {
    $stmt = $conn->prepare("INSERT INTO users (name, email, password_hash, role, status) VALUES ('Admin Utama', :email, :hash, 'admin', 'active')");
    $stmt->execute(['email' => $email, 'hash' => $hash]);
    echo "Akun Admin berhasil dibuat!<br>Email: <b>$email</b><br>Password: <b>$password</b>";
} catch (Exception $e) {
    echo "Gagal membuat akun atau email sudah ada. Error: " . $e->getMessage();
}