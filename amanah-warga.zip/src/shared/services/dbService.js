/**
 * FAKE API & LOCAL DATABASE SERVICE
 * Digunakan untuk pengujian PWA nyata di Frontend (React).
 * Data disimpan di LocalStorage sehingga tidak hilang saat direfresh,
 * dan menggunakan Promise untuk mensimulasikan delay API Server (Axios/Fetch).
 * 
 * Nanti jika Backend PHP 8.3+ Anda sudah siap, Anda cukup mengganti isi 
 * fungsi-fungsi di bawah ini dengan pemanggilan axios.get() atau axios.post().
 */

const DB_KEY = 'amanah_db_v1';

const INITIAL_DATA = {
  profile: { name: 'Graha Mutiara Residence', rt: '17', rw: '45', village: 'Mekar Jaya', district: 'Sukmajaya', city: 'Depok', province: 'Jawa Barat' },
  houses: [
    { id: 'H01', block: 'A1/02', owner: 'Budi Santoso', phone: '081234567890', status: 'Tetap', residents: 4, isOccupied: true },
    { id: 'H02', block: 'A1/03', owner: 'Siti Rahma', phone: '081298765432', status: 'Kontrak', residents: 3, isOccupied: true },
  ],
  billings: [
    { id: 'BILL-01', name: 'Iuran Keamanan & Kebersihan', amount: 75000, type: 'Rutin Bulanan', target: 'Semua Warga', period: 'Oktober 2026', status: 'Aktif' },
    { id: 'BILL-02', name: 'Kas Rutin RT', amount: 25000, type: 'Rutin Bulanan', target: 'Semua Warga', period: 'Oktober 2026', status: 'Aktif' },
  ],
  payments: [
    { id: 'PAY-101', passportId: 'PT-8891', date: '2026-10-21', house: 'A1/02 (Budi Santoso)', billing: 'Iuran Keamanan & Kebersihan', total: 75000, method: 'Transfer QRIS', status: 'Menunggu Verifikasi', proof: 'https://placehold.co/300x400/4f46e5/ffffff?text=Resi' }
  ],
  cashbook: [
    { id: 'TRX-001', passportId: 'PT-8850', date: '2026-10-01', type: 'Pemasukan', category: 'Iuran Warga', description: 'Pembayaran Kas', amount: 25000 },
    { id: 'TRX-002', passportId: 'PT-8802', date: '2026-10-05', type: 'Pengeluaran', category: 'Keamanan', description: 'Honor Satpam', amount: 1800000 }
  ],
  announcements: [
    { id: 'ANN-01', title: 'Kerja Bakti', date: '2026-10-20', author: 'Pak Sarjito', category: 'Kegiatan', content: 'Kerja bakti pembersihan selokan.' }
  ],
  users: [
    { id: 'USR-01', name: 'Pak Sarjito', role: 'Ketua RT (Admin Utama)', email: 'sarjito.rt@kaswarga.id', status: 'Aktif' }
  ]
};

// Inisialisasi Database
const initDB = () => {
  if (!localStorage.getItem(DB_KEY)) {
    localStorage.setItem(DB_KEY, JSON.stringify(INITIAL_DATA));
  }
};

const readDB = () => JSON.parse(localStorage.getItem(DB_KEY));
const writeDB = (data) => localStorage.setItem(DB_KEY, JSON.stringify(data));

// Simulasi Jeda Network (Latency)
const delay = (ms = 300) => new Promise(resolve => setTimeout(resolve, ms));

initDB();

export const apiService = {
  // --- WARGA / HOUSES ---
  getHouses: async () => {
    await delay();
    return readDB().houses;
  },
  addHouse: async (houseData) => {
    await delay(500);
    const db = readDB();
    const newHouse = { ...houseData, id: `H-${Date.now()}` };
    db.houses.unshift(newHouse);
    writeDB(db);
    return newHouse;
  },

  // --- PEMBAYARAN / PAYMENTS ---
  getPayments: async () => {
    await delay();
    return readDB().payments;
  },
  submitPayment: async (paymentData) => {
    await delay(800);
    const db = readDB();
    const newPayment = {
      ...paymentData,
      id: `PAY-${Date.now()}`,
      passportId: `PT-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'Menunggu Verifikasi'
    };
    db.payments.unshift(newPayment);
    writeDB(db);
    return newPayment;
  },
  verifyPayment: async (paymentId, isApproved) => {
    await delay(600);
    const db = readDB();
    const paymentIndex = db.payments.findIndex(p => p.id === paymentId);
    if (paymentIndex > -1) {
      db.payments[paymentIndex].status = isApproved ? 'Terverifikasi' : 'Ditolak';
      
      // Auto input ke buku kas jika disetujui
      if (isApproved) {
        db.cashbook.unshift({
          id: `TRX-${Date.now()}`,
          passportId: db.payments[paymentIndex].passportId,
          date: new Date().toISOString().split('T')[0],
          type: 'Pemasukan',
          category: 'Iuran Warga',
          description: `Pembayaran: ${db.payments[paymentIndex].billing} - ${db.payments[paymentIndex].house}`,
          amount: db.payments[paymentIndex].total
        });
      }
      writeDB(db);
    }
    return true;
  },

  // --- BUKU KAS / CASHBOOK ---
  getCashbook: async () => {
    await delay();
    return readDB().cashbook;
  },
  
  // --- METRIK DASHBOARD ---
  getDashboardMetrics: async () => {
    await delay();
    const db = readDB();
    const totalIncome = db.cashbook.filter(t => t.type === 'Pemasukan').reduce((acc, curr) => acc + Number(curr.amount), 0);
    const totalExpense = db.cashbook.filter(t => t.type === 'Pengeluaran').reduce((acc, curr) => acc + Number(curr.amount), 0);
    const pendingCount = db.payments.filter(p => p.status === 'Menunggu Verifikasi').length;
    
    return {
      balance: 24850000 + totalIncome - totalExpense,
      income: totalIncome,
      expense: totalExpense,
      pendingVerifications: pendingCount
    };
  }
};
