import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import AmanahLogo from '../ui/AmanahLogo';

export default function ResidentLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [userName] = useState("Budi");

  const isActive = (path) => location.pathname.includes(path);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login', { replace: true });
  };

  return (
    <div className="flex-1 flex justify-center bg-slate-100 p-0 sm:p-4 overflow-y-auto w-full min-h-screen font-sans">
      {/* Kontainer Utama menyerupai layar HP */}
      <div className="w-full max-w-md bg-[#F4F7F9] min-h-[100dvh] sm:min-h-[calc(100vh-3.5rem)] sm:rounded-[2.5rem] overflow-hidden flex flex-col sm:shadow-[0_20px_50px_rgba(0,0,0,0.15)] sm:border-[6px] border-white relative">
        
        {/* Area Konten (Header menyatu dengan Hero Section di Dashboard) */}
        <div className="flex-1 overflow-y-auto pb-24 hide-scrollbar">
          <Outlet />
        </div>

        {/* Bottom Navigation ala GoPay (Floating Button di tengah) */}
        <div className="fixed sm:absolute bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-100 shadow-[0_-5px_20px_rgba(0,0,0,0.03)] px-2 pt-2 pb-safe-bottom rounded-t-2xl">
          <div className="flex items-center justify-around h-16 relative">
            
            <Link to="/warga/dashboard" className={`flex flex-col items-center gap-1 flex-1 ${isActive('dashboard') ? 'text-[#0081A0]' : 'text-slate-400 hover:text-slate-600'}`}>
              <i data-lucide="home" className={`w-6 h-6 ${isActive('dashboard') ? 'fill-current' : ''}`}></i>
              <span className="text-[10px] font-bold">Beranda</span>
            </Link>
            
            <Link to="/warga/tagihan" className={`flex flex-col items-center gap-1 flex-1 ${isActive('tagihan') ? 'text-[#0081A0]' : 'text-slate-400 hover:text-slate-600'}`}>
              <i data-lucide="wallet" className={`w-6 h-6 ${isActive('tagihan') ? 'fill-current' : ''}`}></i>
              <span className="text-[10px] font-bold">Tagihan</span>
            </Link>
            
            {/* Tombol Tengah (QRIS / Action Utama) */}
            <div className="flex-1 flex justify-center relative">
              <Link to="/warga/bayar" className="absolute -top-7 flex flex-col items-center justify-center bg-[#00A5CF] hover:bg-[#0091B5] text-white w-14 h-14 rounded-full shadow-[0_8px_16px_rgba(0,165,207,0.3)] transition-transform hover:scale-105 border-4 border-white">
                <i data-lucide="scan-line" className="w-6 h-6"></i>
              </Link>
              <span className="text-[10px] font-bold text-slate-700 mt-8">Bayar</span>
            </div>

            <Link to="/warga/kas" className={`flex flex-col items-center gap-1 flex-1 ${isActive('kas') ? 'text-[#0081A0]' : 'text-slate-400 hover:text-slate-600'}`}>
              <i data-lucide="pie-chart" className={`w-6 h-6 ${isActive('kas') ? 'fill-current' : ''}`}></i>
              <span className="text-[10px] font-bold">Kas RT</span>
            </Link>

            <Link to="/warga/profil" className={`flex flex-col items-center gap-1 flex-1 ${isActive('profil') ? 'text-[#0081A0]' : 'text-slate-400 hover:text-slate-600'}`}>
              <i data-lucide="user" className={`w-6 h-6 ${isActive('profil') ? 'fill-current' : ''}`}></i>
              <span className="text-[10px] font-bold">Profil</span>
            </Link>
            
          </div>
        </div>

      </div>
    </div>
  );
}
