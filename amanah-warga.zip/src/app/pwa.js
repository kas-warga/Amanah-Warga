import { registerSW } from 'virtual:pwa-register';

const updateSW = registerSW({
  onNeedRefresh() {
    if (confirm('Pembaruan aplikasi tersedia. Muat ulang sekarang untuk memperbarui?')) {
      updateSW(true);
    }
  },
  onOfflineReady() {
    console.log('Aplikasi siap digunakan secara luring (offline).');
  },
});