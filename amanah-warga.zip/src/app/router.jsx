import React from 'react';
import { createBrowserRouter, Navigate } from 'react-router-dom';
import AdminLayout from './layouts/AdminLayout';
import ResidentLayout from '../shared/layouts/ResidentLayout'; 
import LoginPage from '../domains/auth/pages/LoginPage';
import DashboardPage from '../domains/dashboard/pages/DashboardPage';
import ResidentsPage from '../domains/residents/pages/ResidentsPage';
import MasterBillingPage from '../domains/billing/pages/MasterBillingPage';
import RegistrationPage from '../domains/public/pages/RegistrationPage';

// Import Halaman Beranda Warga yang baru
import ResidentDashboardPage from '../domains/dashboard/pages/ResidentDashboardPage';

const ModulePlaceholder = ({ title, icon }) => (
  <div className="flex flex-col items-center justify-center min-h-[60vh] p-6 text-center">
    <div className="w-24 h-24 bg-emerald-50 rounded-[2rem] flex items-center justify-center mb-6 shadow-sm border border-emerald-100/50">
      <span className="text-5xl drop-shadow-sm">{icon}</span>
    </div>
    <h1 className="text-2xl font-black text-slate-800 tracking-tight">{title}</h1>
    <p className="text-sm text-slate-500 mt-3 max-w-[250px] leading-relaxed">
      Halaman ini sedang dalam tahap pengembangan sistem modern.
    </p>
  </div>
);

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Navigate to="/admin/dashboard" replace />,
  },
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/pendaftaran-warga',
    element: <RegistrationPage />,
  },
  {
    path: '/admin',
    element: <AdminLayout />,
    children: [
      { index: true, element: <Navigate to="/admin/dashboard" replace /> },
      { path: 'dashboard', element: <DashboardPage /> },
      { path: 'warga', element: <ResidentsPage /> },
      { path: 'master-tagihan', element: <MasterBillingPage /> },
    ],
  },
  {
    path: '/warga',
    element: <ResidentLayout />,
    children: [
      { index: true, element: <Navigate to="/warga/dashboard" replace /> },
      // Menggunakan komponen ResidentDashboardPage untuk rute dashboard warga
      { path: 'dashboard', element: <ResidentDashboardPage /> },
      { path: 'tagihan', element: <ModulePlaceholder title="Kartu Iuran Digital" icon="🧾" /> },
      { path: 'kas', element: <ModulePlaceholder title="Kas RT Transparan" icon="📊" /> },
      { path: 'pengumuman', element: <ModulePlaceholder title="Kabar & Informasi" icon="📢" /> },
      { path: 'profil', element: <ModulePlaceholder title="Profil Saya" icon="👤" /> },
    ],
  }
]);

export default router;
