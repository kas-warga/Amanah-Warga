import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import http from '../../../shared/api/http';

export default function RegistrationPage() {
  const [searchParams] = useSearchParams();
  const refCode = searchParams.get('ref');

  const [formData, setFormData] = useState({
    block: '',
    house_number: '',
    owner_name: '',
    phone_number: '',
    email: '',
    password: '',
    occupancy_status: 'occupied',
    total_residents: 1,
    notes: '',
  });

  const [ktpFile, setKtpFile] = useState(null);
  const [ktpPreview, setKtpPreview] = useState(null);
  
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // States untuk Timer Real-Time
  const [countdown, setCountdown] = useState('');
  const [isExpired, setIsExpired] = useState(false);
  const [isValidTokenFormat, setIsValidTokenFormat] = useState(true);

  // Efek untuk membongkar token URL dan menjalankan hitung mundur
  useEffect(() => {
    if (!refCode) {
      setIsValidTokenFormat(false);
      return;
    }

    try {
      const decoded = atob(refCode);
      const parts = decoded.split('|');
      
      if (parts.length === 3) {
        const expiresAt = parseInt(parts[1], 10) * 1000;
        
        const interval = setInterval(() => {
          const now = new Date().getTime();
          const distance = expiresAt - now;

          if (distance <= 0) {
            clearInterval(interval);
            setCountdown('00:00 (WAKTU HABIS)');
            setIsExpired(true);
          } else {
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            setCountdown(`${minutes}m ${seconds}s`);
            setIsExpired(false);
          }
        }, 1000);

        return () => clearInterval(interval);
      } else {
        setIsValidTokenFormat(false);
      }
    } catch (e) {
      setIsValidTokenFormat(false);
    }
  }, [refCode]);

  const handleImageChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('File harus berupa gambar.');
      e.target.value = '';
      return;
    }

    setKtpPreview((previous) => {
      if (previous) URL.revokeObjectURL(previous);
      return URL.createObjectURL(file);
    });

    setKtpFile(file);
    setErrorMsg('');
  };

  const handleRemoveKtp = () => {
    if (ktpPreview) URL.revokeObjectURL(ktpPreview);
    setKtpFile(null);
    setKtpPreview(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    if (!refCode || !isValidTokenFormat) {
      setErrorMsg('Link pendaftaran rusak atau tidak valid!');
      setLoading(false);
      return;
    }

    if (isExpired) {
      setErrorMsg('Waktu pendaftaran sudah habis. Silakan minta link baru ke Pengurus RT.');
      setLoading(false);
      return;
    }

    if (!ktpFile) {
      setErrorMsg('Mohon unggah foto KTP Anda.');
      setLoading(false);
      return;
    }

    // VALIDASI UKURAN FILE: Maksimal 2MB untuk mencegah PHP membuang payload
    if (ktpFile.size > 2 * 1024 * 1024) {
      setErrorMsg('Ukuran foto KTP terlalu besar! Maksimal 2MB.');
      setLoading(false);
      return;
    }

    try {
      const dataToSend = new FormData();
      // Pastikan kode_lisensi dikemas pada urutan pertama
      dataToSend.append('kode_lisensi', refCode);
      
      Object.keys(formData).forEach(key => {
        dataToSend.append(key, formData[key]);
      });
      dataToSend.append('ktp_image', ktpFile);

      // Memaksa format multipart jika instance http.js secara bawaan menggunakan JSON
      const response = await http.post('/public_registration.php', dataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      if (response.data && response.data.status === 'success') {
        setIsSuccess(true);
      } else {
        setErrorMsg(response.data?.message || 'Gagal mengirim data pendaftaran.');
      }
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Koneksi ke server gagal. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white max-w-md w-full p-8 rounded-3xl shadow-xl text-center space-y-4 border border-slate-100">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto text-4xl font-black mb-2">
            ✓
          </div>
          <h2 className="text-2xl font-black text-slate-800">Pendaftaran Berhasil!</h2>
          <p className="text-slate-500 text-sm leading-relaxed">
            Terima kasih, data hunian Anda telah masuk ke sistem. Akun Warga Anda sudah aktif.
          </p>
          <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 text-left my-4">
            <p className="text-xs font-bold text-emerald-800 mb-2">Informasi Login Akun Warga:</p>
            <p className="text-sm text-emerald-700">Username: <span className="font-bold bg-white px-2 py-0.5 rounded">{formData.phone_number}</span></p>
            <p className="text-sm text-emerald-700 mt-1">Kata Sandi: <span className="italic">(Seperti yang Anda buat)</span></p>
          </div>
          <div className="flex gap-2 justify-center mt-6">
            <button 
              onClick={() => window.location.href = '/login'}
              className="bg-emerald-600 text-white px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-emerald-700 transition w-full"
            >
              Lanjut ke Halaman Login ➔
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6 flex justify-center">
      <div className="max-w-md w-full space-y-6">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 bg-emerald-500 rounded-2xl mx-auto flex items-center justify-center shadow-lg shadow-emerald-500/20 text-slate-950 font-black text-3xl">
            A
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Pendaftaran Warga</h1>
          
          {refCode && isValidTokenFormat ? (
            <div className={`mt-3 inline-flex flex-col items-center p-2 px-6 rounded-2xl border shadow-sm ${isExpired ? 'bg-rose-50 border-rose-200' : 'bg-indigo-50 border-indigo-200'}`}>
              <span className={`text-[10px] font-bold uppercase tracking-wider ${isExpired ? 'text-rose-500' : 'text-indigo-500'}`}>
                Batas Waktu Pendaftaran
              </span>
              <span className={`text-xl font-black tracking-tight mt-0.5 ${isExpired ? 'text-rose-600' : 'text-indigo-700'}`}>
                {isExpired ? 'KADALUARSA' : countdown}
              </span>
            </div>
          ) : (
            <div className="mt-3 inline-block px-4 py-2 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 font-bold text-sm">
              ⚠️ Peringatan: Link Tidak Valid / Palsu
            </div>
          )}
        </div>

        <div className="bg-white rounded-3xl p-5 sm:p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
          {errorMsg && (
            <div className="mb-5 p-3 sm:p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3">
              <span className="text-rose-600 text-lg leading-none">⚠️</span>
              <p className="text-xs sm:text-sm font-medium text-rose-700 leading-snug">{errorMsg}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Blok Rumah</label>
                <input
                  type="text" required placeholder="Cth: A" disabled={isExpired || !isValidTokenFormat}
                  value={formData.block} onChange={(e) => setFormData({ ...formData, block: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 disabled:opacity-50"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Nomor Rumah</label>
                <input
                  type="text" required placeholder="Cth: 12" disabled={isExpired || !isValidTokenFormat}
                  value={formData.house_number} onChange={(e) => setFormData({ ...formData, house_number: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 disabled:opacity-50"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Nama Lengkap Sesuai KTP</label>
              <input
                type="text" required placeholder="Nama Lengkap" disabled={isExpired || !isValidTokenFormat}
                value={formData.owner_name} onChange={(e) => setFormData({ ...formData, owner_name: e.target.value })}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 disabled:opacity-50"
              />
            </div>

            <div className="border-t border-slate-100 pt-4 mt-5 mb-5">
              <h3 className="text-xs font-bold text-slate-800 mb-3 flex items-center justify-between">
                <span>Upload KTP (Wajib)</span>
                <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">Aman & Rahasia</span>
              </h3>
              
              <div className="flex flex-col sm:flex-row gap-3">
                <label className={`flex-1 flex flex-col items-center justify-center px-4 py-3 bg-blue-50 text-blue-700 rounded-xl border border-blue-200 transition-colors text-xs font-bold text-center ${isExpired ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-100 cursor-pointer'}`}>
                  <span className="text-xl mb-1">📸</span>
                  Kamera HP
                  <input type="file" accept="image/*" capture="environment" onChange={handleImageChange} className="hidden" disabled={isExpired || !isValidTokenFormat} />
                </label>

                <div className="flex items-center sm:flex-col justify-center sm:py-2">
                  <div className="flex-grow sm:flex-grow-0 sm:h-full border-t sm:border-l sm:border-t-0 border-slate-200" />
                  <span className="px-3 sm:py-2 text-slate-400 text-[10px] uppercase font-bold">Atau</span>
                  <div className="flex-grow sm:flex-grow-0 sm:h-full border-t sm:border-l sm:border-t-0 border-slate-200" />
                </div>

                <label className={`flex-1 flex flex-col items-center justify-center px-4 py-3 bg-slate-50 text-slate-700 rounded-xl border border-slate-200 transition-colors text-xs font-bold text-center ${isExpired ? 'opacity-50 cursor-not-allowed' : 'hover:bg-slate-100 cursor-pointer'}`}>
                  <span className="text-xl mb-1">📂</span>
                  Galeri / File
                  <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" disabled={isExpired || !isValidTokenFormat} />
                </label>
              </div>

              {ktpPreview && (
                <div className="mt-4 relative rounded-xl overflow-hidden border border-slate-200 shadow-sm">
                  <img src={ktpPreview} alt="Preview KTP" className="w-full h-40 sm:h-48 object-cover bg-slate-50" />
                  <button
                    type="button"
                    onClick={handleRemoveKtp}
                    className="absolute top-2 right-2 bg-rose-600/90 backdrop-blur-sm text-white rounded-lg px-3 py-1.5 text-xs font-bold hover:bg-rose-700 shadow-md transition"
                  >
                    Hapus Foto
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-xs font-bold text-emerald-700 mb-1.5">No. WhatsApp (Username)</label>
                <input
                  type="text" required placeholder="081234..." disabled={isExpired || !isValidTokenFormat}
                  value={formData.phone_number} onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 disabled:opacity-50"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Email (Opsional)</label>
                <input
                  type="email" placeholder="contoh@email.com" disabled={isExpired || !isValidTokenFormat}
                  value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 disabled:opacity-50"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Buat Kata Sandi Akun</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"} required placeholder="Minimal 6 karakter" disabled={isExpired || !isValidTokenFormat}
                  value={formData.password} onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 pr-16 disabled:opacity-50"
                />
                <button
                  type="button" disabled={isExpired || !isValidTokenFormat}
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-emerald-600 font-bold text-[10px] disabled:opacity-50"
                >
                  {showPassword ? "SEMBUNYI" : "LIHAT"}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Jumlah Jiwa</label>
                <input
                  type="number" min="1" required disabled={isExpired || !isValidTokenFormat}
                  value={formData.total_residents} onChange={(e) => setFormData({ ...formData, total_residents: e.target.value })}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 disabled:opacity-50"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Status Hunian</label>
                <select
                  value={formData.occupancy_status} onChange={(e) => setFormData({ ...formData, occupancy_status: e.target.value })} disabled={isExpired || !isValidTokenFormat}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:bg-white focus:ring-2 focus:ring-emerald-500 disabled:opacity-50"
                >
                  <option value="occupied">Milik Pribadi (Dihuni)</option>
                  <option value="rented">Sewa / Kontrak</option>
                  <option value="other">Lainnya</option>
                </select>
              </div>
            </div>

            <button
              type="submit" disabled={loading || !refCode || isExpired || !isValidTokenFormat}
              className={`w-full py-4 mt-6 rounded-xl text-sm font-bold text-white shadow-lg transition-all ${
                (!loading && refCode && !isExpired && isValidTokenFormat) 
                  ? 'bg-emerald-600 hover:bg-emerald-700 hover:-translate-y-0.5 hover:shadow-emerald-500/30' 
                  : 'bg-slate-300 text-slate-500 cursor-not-allowed shadow-none'
              }`}
            >
              {loading ? 'Mengirim Data & KTP...' : (isExpired ? 'Link Sudah Kadaluarsa' : 'Kirim Data Pendataan ➔')}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}