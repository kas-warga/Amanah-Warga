import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchResidents } from '../../residents/api';
import http from '../../../shared/api/http';

export default function DashboardPage() {
  const navigate = useNavigate();

  const [residents, setResidents] = useState([]);
  const [loadingResidents, setLoadingResidents] = useState(true);
  const [summaryKas, setSummaryKas] = useState({ totalKas: 0, pemasukanBulanIni: 0, pengeluaranBulanIni: 0 });
  const [recentActivities, setRecentActivities] = useState([]);
  const [loadingKas, setLoadingKas] = useState(true);
  
  // State untuk Link Pendaftaran Dinamis
  const [isCopying, setIsCopying] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const [generatedLink, setGeneratedLink] = useState('');
  const [expiryTime, setExpiryTime] = useState(null);
  const [countdown, setCountdown] = useState('');

  // Modal States
  const [isIncomeModalOpen, setIsIncomeModalOpen] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);

  const loadResidentsData = async () => {
    try { 
      setLoadingResidents(true); 
      const res = await fetchResidents(); 
      if (res?.status === 'success') setResidents(res.data || []); 
    } catch (err) { 
      setResidents([]); 
    } finally { 
      setLoadingResidents(false); 
    }
  };

  const loadTransactionsData = async () => {
    try { 
      setLoadingKas(true); 
      const res = await http.get('/transactions.php'); 
      if (res?.data?.status === 'success') { 
        setSummaryKas(res.data.summary); 
        setRecentActivities(res.data.data); 
      } 
    } catch (err) {
    } finally { 
      setLoadingKas(false); 
    }
  };

  useEffect(() => { 
    loadResidentsData(); 
    loadTransactionsData(); 
  }, []);

  // Effect untuk Timer Real-Time Link Dinamis
  useEffect(() => {
    if (!expiryTime) return;

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = expiryTime - now;

      if (distance <= 0) {
        clearInterval(interval);
        setCountdown('KADALUARSA');
        setGeneratedLink(''); // Kosongkan link jika sudah hangus
      } else {
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        setCountdown(`${minutes}m ${seconds}s`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [expiryTime]);

  const totalKK = residents.length;
  const totalJiwa = residents.reduce((acc, item) => acc + (parseInt(item.total_residents) || 0), 0);
  const totalOccupied = residents.filter((item) => item.occupancy_status === 'occupied' || item.occupancy_status === 'rented').length;
  const totalVacant = residents.filter((item) => item.occupancy_status === 'vacant').length;

  const formatRupiah = (number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(number || 0);

  // Fungsi Buat & Salin Link Dinamis
  const handleCopyLink = async () => {
    setIsCopying(true);
    try {
      const userData = JSON.parse(localStorage.getItem('user') || '{}');

      if (!userData.id) {
        alert('Sesi login tidak valid. Harap login ulang.');
        setIsCopying(false);
        return;
      }

      const response = await http.post('/generate_reg_link.php', {
        admin_id: userData.id
      });

      if (response.data && response.data.status === 'success') {
        setGeneratedLink(response.data.link);
        
        // Konversi format waktu PHP (Y-m-d H:i:s) ke format yang aman untuk Javascript (ISO 8601)
        const expireDate = new Date(response.data.expires_at.replace(' ', 'T')).getTime();
        setExpiryTime(expireDate);

        await navigator.clipboard.writeText(response.data.link);
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2000);
      } else {
        alert('Gagal membuat link: ' + (response.data?.message || 'Terjadi kesalahan'));
      }
    } catch (error) {
      console.error(error);
      alert('Koneksi server terputus saat membuat link.');
    } finally {
      setIsCopying(false);
    }
  };

  const quickAccess = [
    { title: 'Data Warga', path: '/admin/warga', icon: '👥', color: 'bg-blue-50 text-blue-600', action: null },
    { title: 'Pemasukan', path: '#', icon: '📥', color: 'bg-emerald-50 text-emerald-600', action: () => setIsIncomeModalOpen(true) },
    { title: 'Pengeluaran', path: '#', icon: '📤', color: 'bg-rose-50 text-rose-600', action: () => setIsExpenseModalOpen(true) },
    { title: 'Buku Kas', path: '/admin/kas', icon: '💰', color: 'bg-amber-50 text-amber-600', action: null },
    { title: 'Billing Warga', path: '/admin/billing', icon: '📜', color: 'bg-teal-50 text-teal-600', action: null },
    { title: 'Master Tagihan', path: '/admin/master-tagihan', icon: '⚙️', color: 'bg-purple-50 text-purple-600', action: null },
    { title: 'Approval Bayar', path: '/admin/persetujuan', icon: '✅', color: 'bg-indigo-50 text-indigo-600', action: null },
    { title: 'QRIS RT', path: '/admin/qris', icon: '📱', color: 'bg-slate-100 text-slate-700', action: null },
    { title: 'Pengumuman', path: '/admin/pengumuman', icon: '📢', color: 'bg-cyan-50 text-cyan-600', action: null },
    { title: 'Laporan Kas', path: '/admin/laporan', icon: '📈', color: 'bg-sky-50 text-sky-600', action: null },
    { title: 'Profil RT', path: '/admin/profil-rt', icon: '🏛️', color: 'bg-violet-50 text-violet-600', action: null },
    { title: 'Serah Terima', path: '/admin/serah-terima', icon: '🤝', color: 'bg-orange-50 text-orange-600', action: null },
  ];

  return (
    <div className="p-4 sm:p-6 space-y-6 pb-28 md:pb-8 bg-slate-50/50 min-h-screen">
      
      {/* 1. Wallet Card Premium */}
      <div className="bg-gradient-to-br from-emerald-500 to-teal-700 text-white rounded-3xl p-6 shadow-[0_8px_30px_-4px_rgba(16,185,129,0.3)] relative overflow-hidden">
        <div className="absolute -right-6 -bottom-6 w-40 h-40 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-white/20 to-transparent rounded-bl-full pointer-events-none"></div>
        
        <div className="flex items-center justify-between relative z-10">
          <div>
            <span className="text-[11px] font-semibold text-emerald-50 uppercase tracking-widest block mb-1">
              Total Saldo Kas RT
            </span>
            <h2 className="text-3xl sm:text-4xl font-black tracking-tight drop-shadow-sm">
              {formatRupiah(summaryKas.totalKas)}
            </h2>
          </div>
          <button onClick={() => navigate('/admin/kas')} className="bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/30 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition flex items-center gap-1.5">
            Rincian <span className="text-sm">➔</span>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-5 mt-4 border-t border-white/20 relative z-10">
          <div className="bg-white/15 backdrop-blur-md p-3.5 rounded-2xl border border-white/10">
            <span className="text-[10px] text-emerald-50 block font-medium mb-0.5">Pemasukan Bulan Ini</span>
            <span className="text-sm sm:text-base font-bold text-white drop-shadow-sm">
              +{formatRupiah(summaryKas.pemasukanBulanIni)}
            </span>
          </div>
          <div className="bg-white/15 backdrop-blur-md p-3.5 rounded-2xl border border-white/10">
            <span className="text-[10px] text-emerald-50 block font-medium mb-0.5">Pengeluaran Bulan Ini</span>
            <span className="text-sm sm:text-base font-bold text-white drop-shadow-sm">
              -{formatRupiah(summaryKas.pengeluaranBulanIni)}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Kartu Status Warga */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] flex flex-col items-center text-center space-y-1.5">
          <span className="w-10 h-10 rounded-2xl bg-blue-50/80 text-blue-600 flex items-center justify-center text-lg font-black mb-1">👥</span>
          <span className="text-[10px] sm:text-xs text-slate-400 font-semibold tracking-wide">Total Warga</span>
          <span className="text-xs sm:text-base font-black text-slate-800">{loadingResidents ? '...' : `${totalKK} KK`}</span>
        </div>
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] flex flex-col items-center text-center space-y-1.5">
          <span className="w-10 h-10 rounded-2xl bg-emerald-50/80 text-emerald-600 flex items-center justify-center text-lg font-black mb-1">🏡</span>
          <span className="text-[10px] sm:text-xs text-slate-400 font-semibold tracking-wide">Dihuni / Sewa</span>
          <span className="text-xs sm:text-base font-black text-slate-800">{loadingResidents ? '...' : `${totalOccupied} Rumah`}</span>
        </div>
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] flex flex-col items-center text-center space-y-1.5">
          <span className="w-10 h-10 rounded-2xl bg-slate-50 text-slate-500 flex items-center justify-center text-lg font-black mb-1">🚪</span>
          <span className="text-[10px] sm:text-xs text-slate-400 font-semibold tracking-wide">Rumah Kosong</span>
          <span className="text-xs sm:text-base font-black text-slate-800">{loadingResidents ? '...' : `${totalVacant} Rumah`}</span>
        </div>
      </div>

      {/* 3. Banner Link Pendaftaran Warga - Update Responsif & Real-time Timer */}
      <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-fuchsia-500 rounded-3xl p-4 sm:p-5 text-white shadow-lg shadow-purple-500/20">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 shrink-0 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center text-xl shadow-inner">
              🔗
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base tracking-tight">Form Pendaftaran Warga</h3>
              <p className="text-[10px] sm:text-xs text-indigo-50 mt-0.5">Bagikan link dinamis untuk pendataan mandiri</p>
            </div>
          </div>
          
          {!generatedLink ? (
            <button 
              onClick={handleCopyLink}
              disabled={isCopying}
              className="w-full sm:w-auto bg-white text-indigo-600 px-4 py-2.5 rounded-xl text-xs font-bold hover:bg-indigo-50 hover:scale-105 transition-all active:scale-95 shadow-sm flex items-center justify-center gap-1.5"
            >
              {isCopying ? 'Membuat...' : 'Buat & Salin Link'}
            </button>
          ) : (
            <div className="w-full sm:w-auto flex flex-col gap-2">
              <div className="flex items-center gap-2 bg-white/10 p-2 rounded-lg border border-white/20 backdrop-blur-sm">
                <input 
                  type="text" 
                  readOnly 
                  value={generatedLink} 
                  className="bg-transparent text-xs text-white outline-none w-full sm:w-48 md:w-56 truncate" 
                />
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(generatedLink);
                    setCopySuccess(true);
                    setTimeout(() => setCopySuccess(false), 2000);
                  }}
                  className={`shrink-0 px-3 py-1 rounded-md text-[10px] font-bold transition-colors ${
                    copySuccess ? 'bg-emerald-400 text-white' : 'bg-white text-indigo-600 hover:bg-indigo-50'
                  }`}
                >
                  {copySuccess ? 'Tersalin!' : 'Salin'}
                </button>
              </div>
              <div className="text-[10px] font-medium text-right text-indigo-100">
                {countdown === 'KADALUARSA' ? (
                  <span className="text-rose-200 font-bold bg-rose-500/30 px-2 py-0.5 rounded">Link Kadaluarsa</span>
                ) : (
                  <span>Kadaluarsa dalam: <strong className="text-white bg-white/20 px-1.5 py-0.5 rounded ml-1">{countdown}</strong></span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 4. Akses Cepat Modul */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] space-y-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-bold text-slate-800">Akses Cepat Modul</h3>
          <span className="text-[10px] bg-slate-100 text-slate-500 px-2 py-1 rounded-lg font-semibold">12 Aksi Utama</span>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-12 gap-y-4 gap-x-2">
          {quickAccess.map((item, idx) => (
            <button key={idx} onClick={() => (item.action ? item.action() : navigate(item.path))} className="flex flex-col items-center gap-2 group outline-none">
              <div className={`w-12 h-12 rounded-2xl ${item.color} flex items-center justify-center text-xl font-bold transition-all group-hover:scale-105 group-active:scale-95 group-hover:shadow-md`}>
                {item.icon}
              </div>
              <span className="text-[10px] font-semibold text-slate-600 text-center leading-tight px-1 max-w-full">
                {item.title}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* 5. Histori Aktivitas Terbaru */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] space-y-3">
        <div className="flex items-center justify-between px-1 border-b border-slate-50 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-800">Aktivitas Terbaru</h3>
            <p className="text-[10px] text-slate-400 mt-0.5">Transaksi & perubahan sistem</p>
          </div>
          <button onClick={() => navigate('/admin/kas')} className="text-xs text-emerald-600 font-bold hover:bg-emerald-50 px-3 py-1.5 rounded-lg transition">
            Lihat Semua
          </button>
        </div>

        <div className="divide-y divide-slate-50">
          {loadingKas ? (
            <div className="py-6 text-center text-slate-400 text-xs">Memuat riwayat transaksi...</div>
          ) : recentActivities.length === 0 ? (
            <div className="py-6 text-center text-slate-400 text-xs">Belum ada aktivitas tercatat.</div>
          ) : (
            recentActivities.map((act) => (
              <div key={act.id} className="py-3 flex items-center justify-between gap-3 hover:bg-slate-50/50 transition px-2 rounded-2xl">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-sm shrink-0 ${act.type === 'income' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
                    {act.type === 'income' ? '📥' : '📤'}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-800 truncate">{act.title}</p>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">
                      {act.category} {act.party_name && `• ${act.party_name}`}
                    </p>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className={`text-xs font-black block ${act.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {act.type === 'income' ? '+' : '-'}{formatRupiah(act.amount)}
                  </span>
                  <span className="text-[9px] text-slate-400 mt-0.5 block">{act.transaction_date}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
}