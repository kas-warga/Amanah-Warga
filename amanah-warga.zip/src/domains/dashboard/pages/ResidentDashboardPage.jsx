import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function ResidentDashboardPage() {
  // Mock Data
  const saldoUser = 0; // Saldo e-wallet warga (jika ada)
  const tagihanAktif = 75000;
  
  // Re-initialize lucide icons if they exist in global scope
  useEffect(() => {
    if (window.lucide) {
      window.lucide.createIcons();
    }
  });

  return (
    <div className="w-full bg-[#F4F7F9]">
      {/* Hero Section (Biru Tua GoPay) */}
      <div className="bg-gradient-to-br from-[#00527A] to-[#00709E] text-white pt-10 pb-20 px-5 relative overflow-hidden rounded-b-[2rem]">
        {/* Pola Background Samar */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
        
        {/* Header Top */}
        <div className="flex justify-between items-center relative z-10 mb-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-white/20 rounded-md flex items-center justify-center backdrop-blur-sm">
              <i data-lucide="shield-check" className="w-3.5 h-3.5 text-white"></i>
            </div>
            <span className="font-bold text-sm tracking-wide">AmanahWarga</span>
          </div>
          <button className="bg-white/10 hover:bg-white/20 p-2 rounded-full backdrop-blur-sm transition">
            <i data-lucide="help-circle" className="w-5 h-5"></i>
          </button>
        </div>

        {/* Saldo / Tagihan Area */}
        <div className="relative z-10 flex justify-between items-end">
          <div>
            <p className="text-white/80 text-xs font-medium mb-1">Tagihan Bulan Ini</p>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold">Rp</span>
              <span className="text-4xl font-black tracking-tight">{tagihanAktif.toLocaleString('id-ID')}</span>
              <button className="text-white/60 hover:text-white ml-1">
                <i data-lucide="eye" className="w-5 h-5"></i>
              </button>
            </div>
            <div className="flex items-center gap-2 mt-3 text-xs font-medium text-white/90">
               <i data-lucide="bar-chart-2" className="w-4 h-4 text-emerald-300"></i>
               <span>Kas RT Transparan Rp 24.850.000 &rsaquo;</span>
            </div>
          </div>
          
          {/* Action Buttons Kanan Atas */}
          <div className="flex flex-col gap-2">
            <Link to="/warga/tagihan" className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 flex flex-col items-center justify-center w-14 h-14 rounded-2xl shadow-sm transition">
              <i data-lucide="receipt" className="w-5 h-5 mb-0.5"></i>
              <span className="text-[9px] font-bold">Bayar</span>
            </Link>
            <Link to="/warga/riwayat" className="bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 flex flex-col items-center justify-center w-14 h-14 rounded-2xl shadow-sm transition">
              <i data-lucide="history" className="w-5 h-5 mb-0.5"></i>
              <span className="text-[9px] font-bold">Riwayat</span>
            </Link>
          </div>
        </div>

        {/* Chip Info */}
        <div className="flex gap-2 mt-6 relative z-10 overflow-x-auto hide-scrollbar pb-1">
          <div className="bg-white/10 border border-white/20 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-1.5 whitespace-nowrap">
            <i data-lucide="shield" className="w-3.5 h-3.5 text-blue-200"></i>
            <span className="text-[10px] font-medium">Pembayaran Aman</span>
          </div>
          <div className="bg-white/10 border border-white/20 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-1.5 whitespace-nowrap">
            <i data-lucide="file-text" className="w-3.5 h-3.5 text-emerald-200"></i>
            <span className="text-[10px] font-medium">E-Resi Sah</span>
          </div>
        </div>
      </div>

      {/* Main Grid Menu Card (Melayang di atas background biru) */}
      <div className="px-4 -mt-8 relative z-20">
        <div className="bg-white rounded-3xl p-5 shadow-[0_10px_30px_rgba(0,0,0,0.05)] border border-slate-100">
          <div className="grid grid-cols-4 gap-y-6 gap-x-2">
            
            {/* Menu Items */}
            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-500 relative">
                <i data-lucide="wallet-cards" className="w-6 h-6"></i>
                <span className="absolute -top-1.5 -right-1.5 bg-emerald-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-md border border-white">WAJIB</span>
              </div>
              <span className="text-[10px] font-bold text-slate-700 text-center leading-tight">Bayar<br/>Iuran</span>
            </div>

            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-500">
                <i data-lucide="pie-chart" className="w-6 h-6"></i>
              </div>
              <span className="text-[10px] font-bold text-slate-700 text-center leading-tight">Laporan<br/>Kas</span>
            </div>

            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-orange-50 rounded-2xl flex items-center justify-center text-orange-500">
                <i data-lucide="megaphone" className="w-6 h-6"></i>
              </div>
              <span className="text-[10px] font-bold text-slate-700 text-center leading-tight">Info<br/>Warga</span>
            </div>

            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-purple-50 rounded-2xl flex items-center justify-center text-purple-500">
                <i data-lucide="users" className="w-6 h-6"></i>
              </div>
              <span className="text-[10px] font-bold text-slate-700 text-center leading-tight">Data<br/>Warga</span>
            </div>

            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-500">
                <i data-lucide="alert-triangle" className="w-6 h-6"></i>
              </div>
              <span className="text-[10px] font-bold text-slate-700 text-center leading-tight">Tombol<br/>Darurat</span>
            </div>
            
            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-500">
                <i data-lucide="file-check" className="w-6 h-6"></i>
              </div>
              <span className="text-[10px] font-bold text-slate-700 text-center leading-tight">Surat<br/>Pengantar</span>
            </div>
            
            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-cyan-50 rounded-2xl flex items-center justify-center text-cyan-500">
                <i data-lucide="store" className="w-6 h-6"></i>
              </div>
              <span className="text-[10px] font-bold text-slate-700 text-center leading-tight">UMKM<br/>Lokal</span>
            </div>

            <div className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-500 border border-slate-100">
                <i data-lucide="grid-2x2" className="w-6 h-6"></i>
              </div>
              <span className="text-[10px] font-bold text-slate-700 text-center leading-tight">Semua<br/>Layanan</span>
            </div>

          </div>
        </div>
      </div>

      {/* Section Spesial Buat Kamu */}
      <div className="px-4 mt-6">
        <h3 className="font-bold text-slate-800 text-sm mb-3 px-1">Spesial cuma buat kamu</h3>
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-amber-100 rounded-2xl flex items-center justify-center text-amber-600">
              <i data-lucide="badge-percent" className="w-6 h-6"></i>
            </div>
            <div>
              <p className="font-bold text-sm text-slate-800">Lunas Tepat Waktu</p>
              <p className="text-[10px] text-slate-500 mt-0.5">Terima kasih atas partisipasi Anda.</p>
            </div>
          </div>
          <i data-lucide="chevron-right" className="w-5 h-5 text-slate-400"></i>
        </div>
      </div>
      
    </div>
  );
}
