import React, { useState } from 'react';
import http from '../../../shared/api/http';

export default function GenerateLinkCard() {
  const [link, setLink] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Mengambil data user/admin yang sedang login
  const userData = JSON.parse(localStorage.getItem('user') || '{}');

  const handleGenerate = async () => {
    if (!userData.id) {
      alert('Sesi login tidak valid. Harap login ulang.');
      return;
    }
    
    setLoading(true);
    setCopied(false);
    
    try {
      const response = await http.post('/generate_reg_link.php', {
        admin_id: userData.id
      });
      
      if (response.data && response.data.status === 'success') {
        setLink(response.data.link);
      } else {
        alert('Gagal membuat link: ' + response.data.message);
      }
    } catch (error) {
      alert('Koneksi server terputus.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (link) {
      navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  return (
    <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
      <h3 className="font-bold text-slate-800 text-sm mb-2">Buat Link Pendaftaran Warga</h3>
      <p className="text-xs text-slate-500 mb-4">
        Link bersifat dinamis dan akan otomatis <strong>KADALUARSA dalam 1 Jam</strong> untuk mencegah penyalahgunaan.
      </p>

      <button 
        onClick={handleGenerate} 
        disabled={loading}
        className="bg-emerald-600 text-white text-xs font-bold px-4 py-2 rounded-lg hover:bg-emerald-700 transition"
      >
        {loading ? 'Membuat Link...' : 'Generate Link Baru'}
      </button>

      {link && (
        <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between gap-3">
          <input 
            type="text" 
            readOnly 
            value={link} 
            className="w-full bg-transparent text-xs text-slate-700 outline-none truncate" 
          />
          <button 
            onClick={handleCopy}
            className={`shrink-0 text-xs font-bold px-3 py-1.5 rounded-md transition ${
              copied ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            {copied ? 'Tersalin ✓' : 'Salin Link'}
          </button>
        </div>
      )}
    </div>
  );
}